package com.simplefileencryptor.testv1

import android.app.Activity
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat

private const val APP_ASSET_HOST = "appassets.androidplatform.net"
private const val APP_START_URL = "https://$APP_ASSET_HOST/assets/index.html"

class MainActivity : ComponentActivity() {
    private lateinit var assetLoader: WebViewAssetLoader
    private lateinit var nativeDownloads: NativeDownloadBridge
    private lateinit var saveDocumentLauncher: ActivityResultLauncher<Intent>
    private lateinit var openDocumentLauncher: ActivityResultLauncher<Intent>
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null
    private var sfeWebView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        applySystemTheme(isLight = false)

        nativeDownloads = NativeDownloadBridge(this)
        saveDocumentLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            nativeDownloads.onSaveActivityResult(result)
        }
        openDocumentLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            handleOpenDocumentResult(result)
        }
        assetLoader = WebViewAssetLoader.Builder()
            .setDomain(APP_ASSET_HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Color(0xFF100B1B),
                surface = Color(0xFF21172F),
                primary = Color(0xFFBE79FF),
                secondary = Color(0xFFED65BE),
            )) {
                AndroidView(
                    modifier = Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing),
                    factory = { context ->
                        WebView(context).apply {
                            sfeWebView = this
                            setBackgroundColor(AndroidColor.rgb(16, 11, 27))
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.allowFileAccess = false
                            settings.allowContentAccess = false
                            settings.allowFileAccessFromFileURLs = false
                            settings.allowUniversalAccessFromFileURLs = false
                            settings.javaScriptCanOpenWindowsAutomatically = false
                            settings.mediaPlaybackRequiresUserGesture = true
                            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                            settings.safeBrowsingEnabled = true
                            addJavascriptInterface(nativeDownloads, "SfeNativeDownloads")
                            addJavascriptInterface(NativeDiagnosticsBridge(this@MainActivity), "SfeNativeDiagnostics")
                            webViewClient = object : WebViewClientCompat() {
                                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                                    return assetLoader.shouldInterceptRequest(request.url)
                                }

                                @Suppress("DEPRECATION")
                                override fun shouldInterceptRequest(view: WebView, url: String): WebResourceResponse? {
                                    return assetLoader.shouldInterceptRequest(Uri.parse(url))
                                }

                                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                                    val uri = request.url
                                    // The JS bridge is exposed only to the bundled first-party origin.
                                    return uri.scheme != "https" || uri.host != APP_ASSET_HOST || !uri.path.orEmpty().startsWith("/assets/")
                                }
                            }
                            webChromeClient = object : WebChromeClient() {
                                override fun onShowFileChooser(
                                    webView: WebView?,
                                    filePathCallback: ValueCallback<Array<Uri>>?,
                                    fileChooserParams: FileChooserParams?
                                ): Boolean {
                                    if (filePathCallback == null || fileChooserParams == null) return false
                                    pendingFileCallback?.onReceiveValue(null)
                                    pendingFileCallback = filePathCallback
                                    val acceptTypes = fileChooserParams.acceptTypes
                                        .filter { it.isNotBlank() && it != "*/*" }
                                        .distinct()
                                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                                        addCategory(Intent.CATEGORY_OPENABLE)
                                        type = if (acceptTypes.size == 1) acceptTypes.first() else "*/*"
                                        if (acceptTypes.size > 1) putExtra(Intent.EXTRA_MIME_TYPES, acceptTypes.toTypedArray())
                                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserParams.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    openDocumentLauncher.launch(intent)
                                    return true
                                }
                            }
                            loadUrl(APP_START_URL)
                        }
                    },
                    update = { },
                )
            }
        }
    }

    fun launchSaveDocument(filename: String, mimeType: String) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mimeType.ifBlank { "application/octet-stream" }
            putExtra(Intent.EXTRA_TITLE, filename)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        saveDocumentLauncher.launch(intent)
    }

    fun applySystemTheme(isLight: Boolean) {
        runOnUiThread {
            val barColor = if (isLight) AndroidColor.rgb(245, 240, 251) else AndroidColor.rgb(16, 11, 27)
            window.statusBarColor = barColor
            window.navigationBarColor = barColor
            val controller = WindowInsetsControllerCompat(window, window.decorView)
            controller.isAppearanceLightStatusBars = isLight
            controller.isAppearanceLightNavigationBars = isLight
        }
    }

    private fun handleOpenDocumentResult(result: ActivityResult) {
        val callback = pendingFileCallback ?: return
        pendingFileCallback = null
        val returned = result.data
        val uris = if (result.resultCode != Activity.RESULT_OK || returned == null) {
            null
        } else {
            val clip = returned.clipData
            when {
                clip != null -> Array(clip.itemCount) { index -> clip.getItemAt(index).uri }
                returned.data != null -> arrayOf(returned.data!!)
                else -> null
            }
        }
        callback.onReceiveValue(uris)
    }

    override fun onBackPressed() {
        val view = sfeWebView
        if (view != null && view.canGoBack()) view.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        pendingFileCallback?.onReceiveValue(null)
        pendingFileCallback = null
        sfeWebView?.apply {
            removeJavascriptInterface("SfeNativeDownloads")
            removeJavascriptInterface("SfeNativeDiagnostics")
            stopLoading()
            webChromeClient = null
            webViewClient = null
            (parent as? ViewGroup)?.removeView(this)
            destroy()
        }
        sfeWebView = null
        nativeDownloads.close()
        super.onDestroy()
    }
}
