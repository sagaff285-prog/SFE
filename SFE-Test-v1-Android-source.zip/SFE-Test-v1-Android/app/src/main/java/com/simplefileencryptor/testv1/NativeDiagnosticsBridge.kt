package com.simplefileencryptor.testv1

import android.os.Build
import android.os.Debug
import android.webkit.JavascriptInterface
import org.json.JSONObject

class NativeDiagnosticsBridge(private val activity: MainActivity) {
    @JavascriptInterface
    fun isAvailable(): Boolean = true

    @JavascriptInterface
    fun snapshot(): String {
        return try {
            val native = JSONObject(NativeChecks().snapshotNative())
            JSONObject()
                .put("debuggerConnected", Debug.isDebuggerConnected())
                .put("tracerPid", native.optInt("tracerPid", -1))
                .put("writableExecutableMappings", native.optInt("writableExecutableMappings", -1))
                .put("debuggableBuild", BuildConfig.DEBUG)
                .put("androidApi", Build.VERSION.SDK_INT)
                .toString()
        } catch (_: Exception) {
            JSONObject()
                .put("debuggerConnected", Debug.isDebuggerConnected())
                .put("tracerPid", -1)
                .put("writableExecutableMappings", -1)
                .put("debuggableBuild", BuildConfig.DEBUG)
                .put("androidApi", Build.VERSION.SDK_INT)
                .toString()
        }
    }

    @JavascriptInterface
    fun setLightMode(isLight: Boolean) {
        activity.applySystemTheme(isLight)
    }
}

class NativeChecks {
    external fun snapshotNative(): String

    companion object {
        init { System.loadLibrary("sfe_integrity") }
    }
}
