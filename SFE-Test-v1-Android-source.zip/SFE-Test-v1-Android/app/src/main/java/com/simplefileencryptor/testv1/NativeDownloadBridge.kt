package com.simplefileencryptor.testv1

import android.app.Activity
import android.content.ContentResolver
import android.net.Uri
import android.util.Base64
import android.webkit.JavascriptInterface
import androidx.activity.result.ActivityResult
import org.json.JSONObject
import java.io.OutputStream
import java.util.UUID

/**
 * Local-only streaming Save As bridge. It transfers data between the WebView's
 * SFE Blob and a user-selected SAF destination in 128 KiB chunks. No network path.
 */
class NativeDownloadBridge(private val activity: MainActivity) {
    private data class SaveRequest(
        val id: String,
        val filename: String,
        val mimeType: String,
        val expectedSize: Long,
        @Volatile var status: String = "waiting",
        @Volatile var error: String = "",
        @Volatile var uri: Uri? = null,
        @Volatile var output: OutputStream? = null,
        @Volatile var written: Long = 0L,
    )

    private val lock = Any()
    @Volatile private var current: SaveRequest? = null

    @JavascriptInterface
    fun isAvailable(): Boolean = true

    @JavascriptInterface
    fun requestSave(filename: String, mimeType: String, expectedSize: Long): String {
        val safeName = filename
            .replace('/', '_')
            .replace('\\', '_')
            .filter { it >= ' ' && it != '\u007f' }
            .take(180)
            .ifBlank { "sfe-output.bin" }
        val request = SaveRequest(
            id = UUID.randomUUID().toString(),
            filename = safeName,
            mimeType = mimeType.take(120).ifBlank { "application/octet-stream" },
            expectedSize = expectedSize.coerceAtLeast(0L),
        )
        val alreadySaving = synchronized(lock) {
            val previous = current
            if (previous != null && (previous.status == "waiting" || previous.status == "ready")) {
                true
            } else {
                if (previous != null && previous.status != "done") {
                    deletePartial(activity.contentResolver, previous.uri)
                }
                closeRequestLocked(previous)
                current = request
                false
            }
        }
        if (alreadySaving) return ""
        activity.runOnUiThread { activity.launchSaveDocument(request.filename, request.mimeType) }
        return request.id
    }

    fun onSaveActivityResult(result: ActivityResult) {
        val request = current ?: return
        val uri = if (result.resultCode == Activity.RESULT_OK) result.data?.data else null
        if (uri == null) {
            synchronized(lock) {
                if (current?.id == request.id) {
                    request.status = "cancelled"
                    closeRequestLocked(request)
                }
            }
            return
        }

        request.uri = uri
        Thread({
            try {
                val stream = activity.contentResolver.openOutputStream(uri, "wt")
                    ?: throw IllegalStateException("Could not open selected output")
                synchronized(lock) {
                    if (current?.id != request.id) {
                        stream.close()
                        return@Thread
                    }
                    request.output = stream
                    request.status = "ready"
                }
            } catch (_: Exception) {
                synchronized(lock) {
                    request.error = "Could not open the selected destination."
                    request.status = "error"
                    closeRequestLocked(request)
                }
            }
        }, "sfe-open-save-stream").start()
    }

    @JavascriptInterface
    fun saveStatus(requestId: String): String {
        val request = current
        if (request == null || request.id != requestId) return JSONObject().put("status", "unknown").toString()
        return JSONObject()
            .put("status", request.status)
            .put("error", request.error)
            .put("written", request.written)
            .toString()
    }

    @JavascriptInterface
    fun writeChunk(requestId: String, payloadBase64: String): Boolean {
        synchronized(lock) {
            val request = current ?: return false
            if (request.id != requestId || request.status != "ready") return false
            return try {
                val bytes = Base64.decode(payloadBase64, Base64.NO_WRAP)
                request.output?.write(bytes) ?: throw IllegalStateException("Output stream unavailable")
                request.written += bytes.size.toLong()
                bytes.fill(0)
                true
            } catch (_: Exception) {
                request.error = "A local output chunk could not be written."
                request.status = "error"
                closeRequestLocked(request)
                false
            }
        }
    }

    @JavascriptInterface
    fun finishSave(requestId: String): Boolean {
        synchronized(lock) {
            val request = current ?: return false
            if (request.id != requestId || request.status != "ready") return false
            if (request.written != request.expectedSize) {
                request.error = "The saved byte count did not match the expected output size."
                request.status = "error"
                closeRequestLocked(request)
                deletePartial(activity.contentResolver, request.uri)
                return false
            }
            return try {
                request.output?.flush()
                request.output?.close()
                request.output = null
                request.status = "done"
                true
            } catch (_: Exception) {
                request.error = "The output could not be finalized."
                request.status = "error"
                closeRequestLocked(request)
                deletePartial(activity.contentResolver, request.uri)
                false
            }
        }
    }

    @JavascriptInterface
    fun cancelSave(requestId: String) {
        synchronized(lock) {
            val request = current ?: return
            if (request.id != requestId) return
            closeRequestLocked(request)
            if (request.status != "done") {
                request.status = "cancelled"
                deletePartial(activity.contentResolver, request.uri)
            }
        }
    }

    fun close() {
        synchronized(lock) {
            val request = current
            if (request != null && request.status != "done") {
                deletePartial(activity.contentResolver, request.uri)
            }
            closeRequestLocked(request)
            current = null
        }
    }

    private fun closeRequestLocked(request: SaveRequest?) {
        try { request?.output?.close() } catch (_: Exception) { }
        if (request != null) request.output = null
    }

    private fun deletePartial(resolver: ContentResolver, uri: Uri?) {
        if (uri == null) return
        try { resolver.delete(uri, null, null) } catch (_: Exception) { }
    }
}
