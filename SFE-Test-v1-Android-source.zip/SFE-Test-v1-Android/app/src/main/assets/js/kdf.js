/*
 * Simple File Encryptor 3.0 - key-derivation dispatcher.
 *
 * Argon2id runs in a dedicated, reused worker (js/argon2-worker.js). There is
 * deliberately no main-thread fallback: that would freeze the UI on slower
 * phones. The worker is created only when an operation first needs Argon2id.
 */
"use strict";

(() => {
    const WORKER_START_TIMEOUT_MS = 12000;
    const PROGRESS_STEP = 0.01;

    const pending = new Map();
    let worker = null;
    let workerReady = null;
    let nextRequestId = 1;

    function kdfError(message, code) {
        const error = new Error(message);
        error.code = code;
        return error;
    }

    function rejectAllPending(error) {
        for (const [id, job] of pending) {
            pending.delete(id);
            job.reject(error);
        }
    }

    function discardWorker(candidate, error) {
        if (candidate && candidate === worker) {
            worker = null;
            workerReady = null;
        }
        try { candidate?.terminate(); } catch (_) { /* best-effort cleanup */ }
        if (error) rejectAllPending(error);
    }

    function startWorker() {
        if (typeof Worker !== "function") {
            return Promise.reject(kdfError(
                "This browser cannot run Argon2id in the background. Choose PBKDF2, or open SFE in an up-to-date browser.",
                "KDF_WORKER_UNAVAILABLE"
            ));
        }

        return new Promise((resolve, reject) => {
            let candidate;
            try {
                candidate = new Worker(new URL("js/argon2-worker.js", document.baseURI), {
                    name: "sfe-argon2id"
                });
            } catch (cause) {
                reject(kdfError(
                    "Could not start the Argon2id worker. Open SFE over HTTPS or localhost and try again.",
                    "KDF_WORKER_UNAVAILABLE"
                ));
                return;
            }
            worker = candidate;

            let ready = false;
            let settled = false;
            let readyTimer = 0;

            const settleFailure = (message, code) => {
                const error = kdfError(message, code);
                if (!settled) {
                    settled = true;
                    clearTimeout(readyTimer);
                    reject(error);
                }
                discardWorker(candidate, error);
            };

            candidate.onmessage = event => {
                const message = event.data || {};

                if (message.type === "ready") {
                    ready = true;
                    if (!settled) {
                        settled = true;
                        clearTimeout(readyTimer);
                        resolve(candidate);
                    }
                    return;
                }

                const job = pending.get(message.id);
                if (!job) return;

                if (message.type === "progress") {
                    const value = Math.max(0, Math.min(1, Number(message.progress) || 0));
                    if (value >= 1 || value - job.lastProgress >= PROGRESS_STEP) {
                        job.lastProgress = value;
                        try { job.onProgress?.(value); } catch (_) { /* UI feedback must not fail crypto */ }
                    }
                    return;
                }

                if (message.type === "result" && message.keyBuffer instanceof ArrayBuffer) {
                    pending.delete(message.id);
                    const key = new Uint8Array(message.keyBuffer);
                    if (key.byteLength !== 32) {
                        key.fill(0);
                        job.reject(kdfError("Argon2id returned invalid key material.", "KDF_DERIVATION_FAILED"));
                        return;
                    }
                    job.resolve(key);
                    return;
                }

                if (message.type === "error") {
                    pending.delete(message.id);
                    job.reject(kdfError(
                        message.message || "Argon2id key derivation failed.",
                        message.code || "KDF_DERIVATION_FAILED"
                    ));
                }
            };

            candidate.onerror = event => {
                event.preventDefault?.();
                settleFailure(
                    ready
                        ? "The Argon2id worker stopped unexpectedly. Reload the page and try again."
                        : "Could not load the Argon2id worker. Open SFE over HTTPS or localhost and try again.",
                    ready ? "KDF_WORKER_FAILED" : "KDF_WORKER_UNAVAILABLE"
                );
            };

            candidate.onmessageerror = () => {
                settleFailure(
                    "The Argon2id worker returned an unreadable message. Reload the page and try again.",
                    "KDF_WORKER_FAILED"
                );
            };

            readyTimer = window.setTimeout(() => {
                if (!ready) {
                    settleFailure(
                        "The Argon2id worker took too long to start. Reload the page and try again.",
                        "KDF_WORKER_UNAVAILABLE"
                    );
                }
            }, WORKER_START_TIMEOUT_MS);
        });
    }

    function ensureWorker() {
        if (worker && workerReady) return workerReady;
        workerReady = startWorker();
        // The rejection is delivered to the caller that awaits it; this only
        // prevents an unhandled-rejection warning if nobody is waiting yet.
        workerReady.catch(() => {});
        return workerReady;
    }

    /**
     * Derive a 32-byte key with Argon2id (RFC 9106) inside the worker.
     * @param {Uint8Array} passwordBytes UTF-8 password bytes (copied, caller may wipe).
     * @param {Uint8Array} salt Salt bytes (copied, caller may wipe).
     * @param {{m:number,t:number,p:number,secret?:Uint8Array,ad?:Uint8Array}} params
     * @param {(progress:number)=>void} [onProgress] Progress callback, 0..1.
     * @returns {Promise<Uint8Array>} 32-byte key material. The caller must wipe it.
     */
    async function derive(passwordBytes, salt, params, onProgress) {
        if (!(passwordBytes instanceof Uint8Array) || !(salt instanceof Uint8Array)) {
            throw new TypeError("Argon2id requires byte-array password and salt values.");
        }

        const activeWorker = await ensureWorker();
        const id = nextRequestId++;
        const passwordCopy = passwordBytes.slice();
        const saltCopy = salt.slice();

        return new Promise((resolve, reject) => {
            pending.set(id, { resolve, reject, onProgress, lastProgress: 0 });
            try {
                activeWorker.postMessage({
                    type: "derive",
                    id,
                    passwordBuffer: passwordCopy.buffer,
                    saltBuffer: saltCopy.buffer,
                    params: { m: params.m, t: params.t, p: params.p }
                }, [passwordCopy.buffer, saltCopy.buffer]);
            } catch (cause) {
                pending.delete(id);
                passwordCopy.fill(0);
                saltCopy.fill(0);
                const error = kdfError(
                    "Could not send key-derivation data to the Argon2id worker.",
                    "KDF_WORKER_FAILED"
                );
                error.cause = cause;
                reject(error);
            }
        });
    }

    window.SFEArgon2idClient = Object.freeze({
        derive,
        isSupported: () => typeof Worker === "function"
    });
})();
