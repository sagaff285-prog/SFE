/* ==========================================
   Simple File Encryptor 3.0
   Drag and drop, including folders
========================================== */

"use strict";

let dragDepth = 0;

function isFileDrag(event) {
    const types = event.dataTransfer?.types;
    return Boolean(types) && Array.from(types).includes("Files");
}

/*
 * A file dropped outside the drop zone would otherwise make the browser open it
 * in this tab and lose the current selection. Cancel file drops everywhere; the
 * drop zone below handles the drops it is meant to receive.
 */
window.addEventListener("dragover", event => {
    if (isFileDrag(event)) event.preventDefault();
});

window.addEventListener("drop", event => {
    if (!isFileDrag(event)) return;
    event.preventDefault();

    const insideDropZone = event.target instanceof Node && DOM.dropZone?.contains(event.target);
    if (DOM.dropZone && !insideDropZone) {
        setStatus("Drop files or a folder inside the box to select them.");
    }
});

/*
 * Browsers invalidate DataTransferItem objects once the drop event returns, so
 * the directory entries are captured synchronously here and walked afterwards.
 */
function captureDroppedItems(dataTransfer) {
    const fallbackFiles = Array.from(dataTransfer?.files || []);
    const entries = [];

    for (const item of Array.from(dataTransfer?.items || [])) {
        if (item.kind !== "file" || typeof item.webkitGetAsEntry !== "function") continue;

        const entry = item.webkitGetAsEntry();
        if (entry) entries.push(entry);
    }

    return { fallbackFiles, entries };
}

function readFileEntry(entry) {
    return new Promise((resolve, reject) => entry.file(resolve, reject));
}

function readDirectoryBatch(reader) {
    return new Promise((resolve, reject) => reader.readEntries(resolve, reject));
}

/** Recursively collects files, giving each a webkitRelativePath so folder structure is kept. */
async function walkDroppedEntry(entry, parentPath, collected) {
    const path = parentPath + entry.name;

    if (entry.isFile) {
        const file = await readFileEntry(entry);
        if (parentPath) {
            Object.defineProperty(file, "webkitRelativePath", { value: path, configurable: true });
        }
        collected.push(file);
        return;
    }

    if (entry.isDirectory) {
        const reader = entry.createReader();
        // readEntries returns results in batches; an empty batch means the directory is done.
        for (;;) {
            const batch = await readDirectoryBatch(reader);
            if (!batch.length) break;

            for (const child of batch) {
                await walkDroppedEntry(child, `${path}/`, collected);
            }
        }
    }
}

async function collectDroppedFiles(dataTransfer) {
    const { fallbackFiles, entries } = captureDroppedItems(dataTransfer);
    const containsFolder = entries.some(entry => entry.isDirectory);

    if (!containsFolder) {
        return { files: fallbackFiles, containsFolder };
    }

    const files = [];
    for (const entry of entries) {
        await walkDroppedEntry(entry, "", files);
    }

    return { files, containsFolder };
}

if (DOM.dropZone) {
    DOM.dropZone.addEventListener("dragenter", event => {
        event.preventDefault();
        if (State.busy) return;

        dragDepth += 1;
        DOM.dropZone.classList.add("drag-over");
    });

    DOM.dropZone.addEventListener("dragover", event => {
        event.preventDefault();
        if (event.dataTransfer) {
            event.dataTransfer.dropEffect = State.busy ? "none" : "copy";
        }
        if (!State.busy) DOM.dropZone.classList.add("drag-over");
    });

    DOM.dropZone.addEventListener("dragleave", event => {
        event.preventDefault();
        dragDepth = Math.max(0, dragDepth - 1);

        if (dragDepth === 0) {
            DOM.dropZone.classList.remove("drag-over");
        }
    });

    DOM.dropZone.addEventListener("drop", async event => {
        event.preventDefault();
        dragDepth = 0;
        DOM.dropZone.classList.remove("drag-over");

        if (State.busy) {
            setStatus("Wait for the current operation to finish before choosing files.");
            return;
        }

        // Read the dataTransfer synchronously, before the first await.
        const dataTransfer = event.dataTransfer;
        let selection;

        try {
            selection = await collectDroppedFiles(dataTransfer);
        } catch (error) {
            console.error(error);
            setStatus("Could not read the dropped items. Try selecting them with the button instead.");
            return;
        }

        if (State.mode === "decrypt" && selection.containsFolder) {
            setStatus("Choose one encrypted file to decrypt, not a folder.");
            return;
        }

        if (!selection.files.length) {
            setStatus("Drop files or a folder here to select them.");
            return;
        }

        loadFiles(selection.files);
    });
}
