/* ==========================================
   Simple File Encryptor 3.0
   File selection and validation
========================================== */

"use strict";

/* ---------- Limits ---------- */

// Plaintext limits for encryption. Decryption is limited by the exact size of
// an SFE3 container, which is slightly larger than the plaintext it holds.
const MAX_FILE_SIZE = 1024 * 1024 * 1024;              // 1 GiB per file
const MAX_TOTAL_SIZE = (4 * 1024 * 1024 * 1024) - 1;   // one container's plaintext

/** Largest container the app will open, derived from the format itself. */
function maxContainerBytes() {
    return window.SFE3?.maxContainerBytes ?? Number.MAX_SAFE_INTEGER;
}

/* ---------- Choose File button ---------- */

DOM.chooseFile.addEventListener("click", () => {
    if (State.busy) return;
    DOM.fileInput.click();
});

/* ---------- File picker ---------- */

DOM.fileInput.addEventListener("change", event => {
    const files = Array.from(event.target.files || []);

    if (!files.length) {
        return;
    }

    loadFiles(files);
});

/* ---------- Load files ---------- */

/**
 * Validate a selection for the current mode, store it, and describe it on screen.
 * Returns true when the selection was accepted.
 */
function loadFiles(files) {
    if (State.busy) {
        setStatus("Wait for the current operation to finish before choosing files.");
        return false;
    }

    const validFiles = files.filter(file => file instanceof File);

    if (!validFiles.length) {
        setStatus("Invalid file selection.");
        return false;
    }

    if (State.mode === "decrypt") {
        if (validFiles.length !== 1) {
            setStatus("Choose one encrypted file to decrypt.");
            DOM.fileInput.value = "";
            return false;
        }

        if (validFiles[0].size > maxContainerBytes()) {
            setStatus(`"${validFiles[0].name}" is too large to be an SFE encrypted file.`);
            DOM.fileInput.value = "";
            return false;
        }
    } else {
        // Empty files are valid inputs; they keep their name and restore as zero-byte files.
        const oversized = validFiles.find(file => file.size > MAX_FILE_SIZE);
        if (oversized) {
            setStatus(`"${oversized.name}" is larger than the 1 GB limit per file.`);
            DOM.fileInput.value = "";
            return false;
        }

        const totalSize = validFiles.reduce((sum, file) => sum + file.size, 0);
        if (totalSize > MAX_TOTAL_SIZE) {
            setStatus("The selected files together exceed the size limit for one encrypted container. Select fewer or smaller files.");
            DOM.fileInput.value = "";
            return false;
        }
    }

    State.selectedFiles = validFiles;
    clearOutput();
    renderSelection(validFiles);

    setStatus(validFiles.length === 1 ? "File loaded successfully." : "Files loaded successfully.");
    return true;
}

/** Shows what is selected. Built with DOM nodes so file names are never parsed as HTML. */
function renderSelection(files) {
    const container = DOM.selectedFile;
    container.replaceChildren();

    const heading = document.createElement("strong");
    heading.textContent = getSelectionCountLabel(files);
    container.appendChild(heading);

    const folderName = getFolderNameFromSelection(files);
    if (folderName) {
        container.appendChild(document.createElement("br"));
        container.appendChild(document.createTextNode(`Folder: ${folderName}`));
    }

    const list = document.createElement("ul");
    list.className = "file-selection-list";

    for (const file of files.slice(0, 5)) {
        const item = document.createElement("li");
        item.textContent = `${getRelativePath(file)} `;

        const size = document.createElement("span");
        size.className = "muted";
        size.textContent = `(${bytesToSize(file.size)})`;
        item.appendChild(size);
        list.appendChild(item);
    }

    const remaining = files.length - 5;
    if (remaining > 0) {
        const more = document.createElement("li");
        more.className = "muted";
        more.textContent = `…and ${remaining} more`;
        list.appendChild(more);
    }

    container.appendChild(list);
}

/* ---------- Clear file ---------- */

function clearFile() {
    State.selectedFiles = [];
    DOM.fileInput.value = "";
    DOM.selectedFile.textContent = "No files selected";
    clearOutput();
}

/* ---------- Validation ---------- */

function hasFiles() {
    if (!State.selectedFiles.length) {
        setStatus("Please choose a file or folder first.");
        return false;
    }

    if (State.mode === "decrypt" && State.selectedFiles.length !== 1) {
        setStatus("Please choose one encrypted file to decrypt.");
        return false;
    }

    return true;
}
