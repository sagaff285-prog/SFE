/* ==========================================
   Simple File Encryptor 3.0
   Application controller
========================================== */

"use strict";

/* ---------- Process ---------- */

DOM.actionButton.addEventListener("click", processAction);

async function processAction() {
    if (State.busy) {
        return;
    }

    if (!hasFiles()) {
        return;
    }

    // Copy the visible security inputs into State right before the run. A value
    // typed but not yet committed (no blur) would otherwise be ignored.
    if (State.mode === "encrypt") {
        try {
            commitSecurityInputs();
        } catch (error) {
            setStatus(error.message);
            return;
        }
    }

    if (!validatePassword()) {
        return;
    }

    await processFiles(State.selectedFiles, getPassword());
}

/* ---------- Keyboard shortcut ----------
   Enter submits from the password fields only, so tabs, menus and other
   controls keep their native keyboard behaviour. */

document.addEventListener("keydown", event => {
    const target = event.target;
    const isPasswordField = target === DOM.password || target === DOM.confirmPassword;

    if (event.key === "Enter" && isPasswordField && !event.isComposing) {
        event.preventDefault();
        processAction();
    }
});

/* ---------- Leaving during work ----------
   Closing or reloading the tab mid-operation would discard the work in progress. */

window.addEventListener("beforeunload", event => {
    if (!State.busy) return;

    event.preventDefault();
    event.returnValue = "";
});
