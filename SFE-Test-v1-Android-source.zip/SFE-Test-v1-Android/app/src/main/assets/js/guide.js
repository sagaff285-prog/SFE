/* Compact first-run guide. No framework or network requests. */
"use strict";

(() => {
    const toggle = document.getElementById("quickGuideToggle");
    const wrapper = document.querySelector(".quick-guide");
    const panel = document.getElementById("quickGuidePanel");
    const eyebrow = document.getElementById("quickGuideEyebrow");

    if (!toggle || !wrapper || !panel || !eyebrow) return;

    const encryptSteps = [
        ["Choose your files", "Pick a file, several files, or switch to Folder."],
        ["Set a password", "Use a long, unique password and keep it somewhere safe."],
        ["Tap Encrypt Files", "SFE protects them right here. Nothing gets uploaded."],
        ["Download your file", "Save the .sfe3 file. You will need the password to unlock it later."]
    ];

    const decryptSteps = [
        ["Choose the encrypted file", "Select an .sfe3 file. Older .sfe files are supported too."],
        ["Enter its password", "Use the same password that was used to protect it."],
        ["Tap Decrypt File", "SFE checks the file and restores it on this device."],
        ["Download the restored file", "Several restored files are packed into one ZIP download."]
    ];

    function setGuideMode(mode) {
        const isDecrypt = mode === "decrypt";
        const steps = isDecrypt ? decryptSteps : encryptSteps;
        eyebrow.textContent = isDecrypt
            ? "Need to restore a file? Here is how in 4 steps"
            : "New here? Protect a file in 4 simple steps";

        steps.forEach(([title, description], index) => {
            const titleNode = document.getElementById(`quickGuideStep${index + 1}Title`);
            const descriptionNode = document.getElementById(`quickGuideStep${index + 1}Text`);
            if (titleNode) titleNode.textContent = title;
            if (descriptionNode) descriptionNode.textContent = description;
        });

        const note = panel.querySelector(".quick-guide__note");
        if (note) {
            note.textContent = isDecrypt
                ? "Your password is never saved by SFE. A wrong password or damaged file cannot be restored."
                : "Forgotten password = no recovery. Keep a safe copy of it.";
        }
    }

    let panelAnimation = null;
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

    function setExpanded(expanded) {
        toggle.setAttribute("aria-expanded", String(expanded));
        toggle.setAttribute("aria-label", expanded ? "Collapse the four-step guide" : "Expand the four-step guide");
        panel.setAttribute("aria-hidden", String(!expanded));
        panel.inert = !expanded;

        if (panelAnimation) {
            panelAnimation.cancel();
            panelAnimation = null;
        }

        const currentHeight = panel.getBoundingClientRect().height;
        wrapper.classList.toggle("is-expanded", expanded);
        panel.style.marginTop = expanded ? "9px" : "0px";

        if (reducedMotion.matches || typeof panel.animate !== "function") {
            panel.style.height = expanded ? "auto" : "0px";
            return;
        }

        // Animate measured height instead of grid track sizing; fade/translate the
        // contents separately so their visual entrance can stay compositor-friendly.
        const targetHeight = expanded ? panel.scrollHeight : 0;
        panel.style.height = `${currentHeight}px`;
        void panel.offsetHeight;
        panelAnimation = panel.animate(
            [{ height: `${currentHeight}px` }, { height: `${targetHeight}px` }],
            { duration: expanded ? 250 : 210, easing: "cubic-bezier(.22, .8, .22, 1)", fill: "forwards" }
        );
        panelAnimation.onfinish = () => {
            panel.style.height = expanded ? "auto" : "0px";
            panelAnimation.cancel(); // Clear the finished fill effect so inline height takes over.
            panelAnimation = null;
        };
    }

    toggle.addEventListener("click", () => {
        setExpanded(toggle.getAttribute("aria-expanded") !== "true");
    });

    document.getElementById("encryptTab")?.addEventListener("click", () => setGuideMode("encrypt"));
    document.getElementById("decryptTab")?.addEventListener("click", () => setGuideMode("decrypt"));

    setGuideMode("encrypt");
    setExpanded(false);
})();
