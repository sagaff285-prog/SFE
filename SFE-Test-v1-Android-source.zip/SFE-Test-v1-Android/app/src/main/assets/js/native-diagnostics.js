"use strict";

(() => {
  const nativeDownloads = window.SfeNativeDownloads;
  const nativeDiagnostics = window.SfeNativeDiagnostics;
  const folderPicker = document.getElementById("pickerFolder");
  const runButton = document.getElementById("runIntegrityChecks");
  const summary = document.getElementById("integritySummary");
  const result = document.getElementById("integrityResult");

  // Android's Storage Access Framework does not expose webkitdirectory in a
  // compatible way, so Test v1 offers single-file and multi-file selection.
  if (nativeDownloads && folderPicker) {
    folderPicker.hidden = true;
  }

  if (nativeDiagnostics && typeof nativeDiagnostics.snapshot === "function" && runButton) {
    runButton.disabled = false;
    if (summary) summary.textContent = "Checks inspect this app process only. Results are local and advisory.";
    runButton.addEventListener("click", () => {
      runButton.disabled = true;
      if (result) result.textContent = "Checking local runtime signals…";
      try {
        const data = JSON.parse(nativeDiagnostics.snapshot());
        const rows = [
          ["Debugger attached", data.debuggerConnected ? "Detected" : "Not detected"],
          ["Tracer process", data.tracerPid > 0 ? "Detected (PID " + data.tracerPid + ")" : data.tracerPid === 0 ? "Not detected" : "Unavailable"],
          ["Writable + executable mappings", data.writableExecutableMappings >= 0 ? String(data.writableExecutableMappings) + " detected" : "Unavailable"],
          ["Debug build", data.debuggableBuild ? "Yes" : "No"]
        ];
        if (result) {
          result.replaceChildren();
          const list = document.createElement("dl");
          list.className = "integrity-result-list";
          for (const [label, value] of rows) {
            const wrapper = document.createElement("div");
            const dt = document.createElement("dt");
            const dd = document.createElement("dd");
            dt.textContent = label;
            dd.textContent = value;
            wrapper.append(dt, dd);
            list.appendChild(wrapper);
          }
          result.appendChild(list);
          const caution = document.createElement("p");
          caution.className = "integrity-result-caution";
          caution.textContent = "Signals are heuristics, may have false positives, and can be bypassed. A clean result is not proof the device is uncompromised.";
          result.appendChild(caution);
        }
      } catch (error) {
        if (result) result.textContent = "The local diagnostics could not run. Encryption remains independent of these checks.";
      } finally {
        runButton.disabled = false;
      }
    });
  } else if (runButton) {
    runButton.disabled = true;
    if (summary) summary.textContent = "Native checks are unavailable in a browser preview. Open the Android Test v1 build to run them.";
  }

  const syncSystemBars = () => {
    if (!nativeDiagnostics || typeof nativeDiagnostics.setLightMode !== "function") return;
    nativeDiagnostics.setLightMode(document.documentElement.dataset.theme !== "dark");
  };
  syncSystemBars();
  try {
    const observer = new MutationObserver(syncSystemBars);
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
  } catch (_) {}
})();
