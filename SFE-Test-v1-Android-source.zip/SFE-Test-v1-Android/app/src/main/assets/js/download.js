/* ==========================================
   Simple File Encryptor 3.0
   Saving the output
========================================== */

"use strict";

DOM.downloadButton.addEventListener("click", downloadOutput);

async function downloadOutput() {
    const blob = getOutputBlob();

    if (!blob) {
        setStatus("There is no file to download.");
        return;
    }

    if (window.SfeNativeDownloads && typeof window.SfeNativeDownloads.requestSave === "function") {
        await saveThroughAndroid(blob, State.outputName);
        return;
    }

    try {
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");

        link.href = url;
        link.download = State.outputName;
        document.body.appendChild(link);
        link.click();
        link.remove();

        // Mobile browsers may take a while to start reading the object URL. Keep it
        // alive long enough for the download to begin, then release the memory.
        window.setTimeout(() => URL.revokeObjectURL(url), 60000);

        setStatus("Download started. Check your browser's downloads.");
    } catch (error) {
        console.error(error);
        setStatus("Download failed. Try again.");
    }
}


// Save native APK output through Android's document picker without broad file permissions.
// Transfer is chunked so the entire encrypted/decrypted output is never base64-encoded at once.
async function saveThroughAndroid(blob, filename) {
    const bridge = window.SfeNativeDownloads;
    let requestId = "";
    const chunkSize = 128 * 1024;

    try {
        requestId = bridge.requestSave(filename, blob.type || "application/octet-stream", blob.size);
        if (!requestId) {
            setStatus("A save is already in progress. Finish or cancel it before starting another save.");
            return;
        }
        const deadline = Date.now() + 5 * 60 * 1000;
        let status = "waiting";
        while (Date.now() < deadline) {
            const response = JSON.parse(bridge.saveStatus(requestId));
            status = response.status;
            if (status === "ready" || status === "cancelled" || status === "error") break;
            await new Promise(resolve => window.setTimeout(resolve, 180));
        }

        if (status === "cancelled") {
            setStatus("Save cancelled. No output was written.");
            return;
        }
        if (status !== "ready") {
            throw new Error("The Android save destination was not ready.");
        }

        for (let offset = 0; offset < blob.size; offset += chunkSize) {
            const bytes = new Uint8Array(await blob.slice(offset, Math.min(offset + chunkSize, blob.size)).arrayBuffer());
            let binary = "";
            for (let i = 0; i < bytes.length; i += 8192) {
                binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + 8192, bytes.length)));
            }
            const encoded = btoa(binary);
            bytes.fill(0);
            if (!bridge.writeChunk(requestId, encoded)) {
                throw new Error("A file chunk could not be written.");
            }
            if (blob.size > chunkSize) {
                const percent = Math.min(99, Math.floor(((offset + chunkSize) / blob.size) * 100));
                setStatus("Saving locally… " + percent + "%");
            }
        }

        if (!bridge.finishSave(requestId)) {
            throw new Error("The saved file did not pass the final write check.");
        }
        setStatus("Saved locally. Check the location you selected.");
    } catch (error) {
        if (requestId) {
            try { bridge.cancelSave(requestId); } catch (_) {}
        }
        console.error("SFE native save failed:", error);
        setStatus("Saving failed. Try again and select a writable destination.");
    }
}
