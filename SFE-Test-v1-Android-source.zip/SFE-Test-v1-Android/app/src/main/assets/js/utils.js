/* ==========================================
   Simple File Encryptor 3.0
   Shared state, DOM access and small helpers
========================================== */

"use strict";

/* ---------- DOM cache ---------- */

const $id = id => document.getElementById(id);

const DOM = {
    encryptTab: $id("encryptTab"),
    decryptTab: $id("decryptTab"),
    fileInput: $id("fileInput"),
    chooseFile: $id("chooseFile"),
    pickerSingle: $id("pickerSingle"),
    pickerFiles: $id("pickerFiles"),
    pickerFolder: $id("pickerFolder"),
    dropZone: $id("dropZone"),
    selectedFile: $id("selectedFile"),
    password: $id("password"),
    confirmPassword: $id("confirmPassword"),
    showPassword: $id("showPassword"),
    generatePassword: $id("generatePassword"),
    passwordGenerator: $id("passwordGenerator"),
    passwordSectionTitle: $id("passwordSectionTitle"),
    strengthTracker: $id("strengthTracker"),
    securityOptions: $id("securityOptions"),
    strength: $id("strength"),
    actionButton: $id("actionButton"),
    progressTrack: $id("progressTrack"),
    progressBar: $id("progressBar"),
    status: $id("status"),
    outputFilename: $id("outputFilename"),
    outputState: $id("outputState"),
    outputCard: document.querySelector(".step-four"),
    downloadButton: $id("downloadButton"),
    argonMemoryRange: $id("argonMemoryRange"),
    argonMemoryInput: $id("argonMemoryInput"),
    argonMemoryValue: $id("argonMemoryValue"),
    argonControls: $id("argonControls"),
    pbkdf2Controls: $id("pbkdf2Controls"),
    pbkdf2IterationsRange: $id("pbkdf2IterationsRange"),
    pbkdf2IterationsInput: $id("pbkdf2IterationsInput"),
    pbkdf2IterationsValue: $id("pbkdf2IterationsValue"),
    kdfPicker: $id("kdfPicker"),
    kdfTrigger: $id("kdfTrigger"),
    kdfMenu: $id("kdfMenu"),
    kdfOptions: document.querySelectorAll(".kdf-picker__option"),
    kdfValue: document.querySelector(".kdf-picker__value"),
    strengthScore: $id("strengthScore"),
    strengthMeterBar: $id("strengthMeterBar"),
    strengthAdvice: $id("strengthAdvice")
};

/* ---------- Application state ----------
   State is the single source of truth for every setting an operation uses.
   The visible controls read from it and write to it; processing never reads
   the DOM directly. */

const ARGON2_MIN_MIB = 12;
const ARGON2_MAX_MIB = 256;
const PBKDF2_MIN_ITERATIONS = 600000;
const PBKDF2_MAX_ITERATIONS = 2000000;

const State = {
    mode: "encrypt",
    selectedFiles: [],
    pickerMode: "single",
    previousEncryptPickerMode: "single",
    encryptedBlob: null,
    decryptedBlob: null,
    outputName: "",
    busy: false,
    kdf: "argon2id",
    argonMemoryKib: 64 * 1024,
    pbkdf2Iterations: 600000,
    argon2Available: typeof Worker === "function"
};

/* ---------- Status ---------- */

function setStatus(message) {
    DOM.status.textContent = message;
}

function clearStatus() {
    setStatus("Waiting...");
}

/* ---------- Progress ---------- */

function setProgress(percent) {
    const value = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
    DOM.progressBar.style.width = `${value}%`;
    DOM.progressTrack?.setAttribute("aria-valuenow", String(value));
}

function resetProgress() {
    setProgress(0);
}

function completeProgress() {
    setProgress(100);
}

/* ---------- Download button ---------- */

function enableDownload() {
    DOM.downloadButton.disabled = false;
}

function disableDownload() {
    DOM.downloadButton.disabled = true;
}

/* ---------- Security settings ----------
   Parsing and range checks live here so the UI and the crypto layer agree. */

function setArgon2MemoryMiB(memoryMiB) {
    const value = Number(memoryMiB);

    if (!Number.isInteger(value) || value < ARGON2_MIN_MIB || value > ARGON2_MAX_MIB) {
        throw new Error(`Argon2id memory must be a whole number from ${ARGON2_MIN_MIB} to ${ARGON2_MAX_MIB} MiB.`);
    }

    State.argonMemoryKib = value * 1024;
    return value;
}

function getPbkdf2Iterations() {
    return State.pbkdf2Iterations;
}

function setPbkdf2Iterations(iterations) {
    const value = Number(iterations);

    if (!Number.isSafeInteger(value) || value < PBKDF2_MIN_ITERATIONS || value > PBKDF2_MAX_ITERATIONS) {
        throw new Error(
            `PBKDF2 iterations must be a whole number from ${PBKDF2_MIN_ITERATIONS.toLocaleString()} to ${PBKDF2_MAX_ITERATIONS.toLocaleString()}.`
        );
    }

    State.pbkdf2Iterations = value;
    return value;
}

/**
 * Copies the visible security inputs into State. Throws an Error with a
 * sentence the person can act on if an input holds an invalid value.
 * Called immediately before every encryption run.
 */
function commitSecurityInputs() {
    if (State.kdf === "argon2id" && DOM.argonMemoryInput) {
        setArgon2MemoryMiB(DOM.argonMemoryInput.value);
    }

    if (State.kdf === "pbkdf2" && DOM.pbkdf2IterationsInput) {
        setPbkdf2Iterations(DOM.pbkdf2IterationsInput.value);
    }
}

function updateSecurityControlsUI() {
    const encryptMode = State.mode === "encrypt";
    const argonVisible = State.kdf === "argon2id";
    const pbkdf2Visible = State.kdf === "pbkdf2";
    const disabled = State.busy || !encryptMode;

    if (DOM.securityOptions) {
        DOM.securityOptions.hidden = !encryptMode;
    }

    if (DOM.kdfTrigger) {
        DOM.kdfTrigger.disabled = disabled;
    }

    if (DOM.argonControls) {
        DOM.argonControls.hidden = !argonVisible;
    }

    if (DOM.pbkdf2Controls) {
        DOM.pbkdf2Controls.hidden = !pbkdf2Visible;
    }

    const memoryMiB = Math.round(State.argonMemoryKib / 1024);
    if (DOM.argonMemoryRange) {
        DOM.argonMemoryRange.value = String(memoryMiB);
        DOM.argonMemoryRange.disabled = disabled || !argonVisible;
    }
    if (DOM.argonMemoryInput) {
        DOM.argonMemoryInput.value = String(memoryMiB);
        DOM.argonMemoryInput.disabled = disabled || !argonVisible;
    }
    if (DOM.argonMemoryValue) {
        DOM.argonMemoryValue.textContent = `${memoryMiB} MiB`;
    }

    const iterations = getPbkdf2Iterations();
    if (DOM.pbkdf2IterationsRange) {
        DOM.pbkdf2IterationsRange.value = String(Math.min(PBKDF2_MAX_ITERATIONS, Math.max(PBKDF2_MIN_ITERATIONS, iterations)));
        DOM.pbkdf2IterationsRange.disabled = disabled || !pbkdf2Visible;
    }
    if (DOM.pbkdf2IterationsInput) {
        DOM.pbkdf2IterationsInput.value = String(iterations);
        DOM.pbkdf2IterationsInput.disabled = disabled || !pbkdf2Visible;
    }
    if (DOM.pbkdf2IterationsValue) {
        DOM.pbkdf2IterationsValue.textContent = iterations.toLocaleString();
    }
}

/* ---------- Busy state ----------
   One switch disables every control that could start, redirect, or replace an
   operation while it runs. Anything that changes State must check State.busy. */

function setBusy(value) {
    State.busy = Boolean(value);

    const lockedControls = [
        DOM.actionButton,
        DOM.chooseFile,
        DOM.fileInput,
        DOM.encryptTab,
        DOM.decryptTab,
        DOM.pickerSingle,
        DOM.pickerFiles,
        DOM.pickerFolder
    ];

    for (const control of lockedControls) {
        if (control) control.disabled = State.busy;
    }

    if (DOM.encryptTab) DOM.encryptTab.setAttribute("aria-disabled", String(State.busy));
    if (DOM.decryptTab) DOM.decryptTab.setAttribute("aria-disabled", String(State.busy));

    updateSecurityControlsUI();
    if (DOM.outputState && !getOutputBlob()) {
        DOM.outputState.textContent = State.busy ? "Processing…" : "Waiting for output";
    }
    if (typeof updatePasswordSection === "function") {
        updatePasswordSection();
    }
}

/* ---------- Output ---------- */

function clearOutput() {
    State.encryptedBlob = null;
    State.decryptedBlob = null;
    State.outputName = "";

    DOM.outputFilename.textContent = "No file generated.";
    if (DOM.outputState) DOM.outputState.textContent = State.busy ? "Processing…" : "Waiting for output";
    DOM.outputCard?.classList.remove("has-output");
    DOM.downloadButton.removeAttribute("aria-label");

    disableDownload();
    resetProgress();
}

function setOutput(blob, filename) {
    if (State.mode === "encrypt") {
        State.encryptedBlob = blob;
        State.decryptedBlob = null;
    } else {
        State.decryptedBlob = blob;
        State.encryptedBlob = null;
    }

    State.outputName = filename;

    DOM.outputFilename.textContent = filename;
    if (DOM.outputState) DOM.outputState.textContent = "✓ File ready";
    DOM.outputCard?.classList.add("has-output");
    DOM.downloadButton.setAttribute("aria-label", `Download ${filename}`);

    enableDownload();
}

function getOutputBlob() {
    return State.mode === "encrypt" ? State.encryptedBlob : State.decryptedBlob;
}

/* ---------- Picker mode ---------- */

function setPickerMode(mode, options = {}) {
    const allowed = ["single", "multiple", "folder"];
    const nextMode = allowed.includes(mode) ? mode : "single";

    if (State.mode === "encrypt") {
        State.pickerMode = nextMode;
    } else {
        if (options.preservePrevious !== false) {
            State.previousEncryptPickerMode = nextMode;
        }
        State.pickerMode = "single";
    }

    syncPickerInputMode();
    updatePickerModeUI();
}

function syncPickerInputMode() {
    DOM.fileInput.multiple = State.mode === "encrypt" && State.pickerMode !== "single";

    if (State.mode === "encrypt" && State.pickerMode === "folder") {
        DOM.fileInput.setAttribute("webkitdirectory", "");
    } else {
        DOM.fileInput.removeAttribute("webkitdirectory");
    }
}

function updatePickerModeUI() {
    const encrypting = State.mode === "encrypt";
    const singleActive = encrypting && State.pickerMode === "single";
    const multipleActive = encrypting && State.pickerMode === "multiple";
    const folderActive = encrypting && State.pickerMode === "folder";

    if (DOM.pickerSingle) {
        DOM.pickerSingle.classList.toggle("active", singleActive);
        DOM.pickerSingle.setAttribute("aria-pressed", String(singleActive));
        DOM.pickerSingle.disabled = State.busy || !encrypting;
    }

    if (DOM.pickerFiles) {
        DOM.pickerFiles.classList.toggle("active", multipleActive);
        DOM.pickerFiles.setAttribute("aria-pressed", String(multipleActive));
        DOM.pickerFiles.disabled = State.busy || !encrypting;
    }

    if (DOM.pickerFolder) {
        DOM.pickerFolder.classList.toggle("active", folderActive);
        DOM.pickerFolder.setAttribute("aria-pressed", String(folderActive));
        DOM.pickerFolder.disabled = State.busy || !encrypting;
    }

    if (DOM.chooseFile) {
        DOM.chooseFile.textContent = !encrypting ? "Choose encrypted file" : folderActive ? "Choose folder" : singleActive ? "Choose one file" : "Choose multiple files";
    }
}

/* ---------- Formatting ---------- */

const SIZE_UNITS = ["Bytes", "KB", "MB", "GB", "TB"];

function bytesToSize(bytes) {
    if (bytes === 0) return "0 Bytes";

    const index = Math.min(SIZE_UNITS.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
    return `${(bytes / Math.pow(1024, index)).toFixed(2)} ${SIZE_UNITS[index]}`;
}

function randomHex(byteLength = 16) {
    if (!Number.isInteger(byteLength) || byteLength < 1 || byteLength > 64) {
        throw new Error("Invalid random filename length.");
    }

    const bytes = new Uint8Array(byteLength);
    crypto.getRandomValues(bytes);

    let output = "";
    for (const byte of bytes) {
        output += byte.toString(16).padStart(2, "0");
    }

    bytes.fill(0);
    return output;
}

/* ---------- File names ---------- */

function removeExtension(filename) {
    const index = filename.lastIndexOf(".");
    return index === -1 ? filename : filename.substring(0, index);
}

/** SFE3 output never reuses the original name: it is random hex plus .sfe3. */
function buildEncryptedName() {
    return `${randomHex(16)}.sfe3`;
}

function buildDecryptedName(filename) {
    if (filename.endsWith(".sfe3")) {
        return `${filename.slice(0, -5)}_decrypted`;
    }

    if (filename.endsWith(".sfe")) {
        return filename.slice(0, -4);
    }

    return `${removeExtension(filename)}_decrypted`;
}

function getRelativePath(file) {
    if (file && typeof file.webkitRelativePath === "string" && file.webkitRelativePath.length > 0) {
        return file.webkitRelativePath;
    }

    return file.name;
}

function getFolderNameFromSelection(files) {
    if (!Array.isArray(files) || files.length === 0) return "";

    const first = files[0];
    if (!first || typeof first.webkitRelativePath !== "string" || first.webkitRelativePath.length === 0) {
        return "";
    }

    const parts = first.webkitRelativePath.split("/");
    return parts.length > 1 ? parts[0] : "";
}

function getSelectionCountLabel(files) {
    const count = Array.isArray(files) ? files.length : 0;
    return count === 1 ? "1 file selected" : `${count} files selected`;
}

/* ---------- Browser support ---------- */

function browserSupported() {
    return Boolean(
        window.isSecureContext &&
        window.crypto &&
        window.crypto.subtle &&
        window.File &&
        window.Blob &&
        window.TextEncoder &&
        window.TextDecoder
    );
}

function requireBrowserSupport() {
    if (browserSupported()) {
        return true;
    }

    setStatus("This page needs a secure context (HTTPS or localhost) and a current browser. Encryption is disabled.");
    DOM.actionButton.disabled = true;
    DOM.chooseFile.disabled = true;
    DOM.fileInput.disabled = true;
    return false;
}

/* ---------- Reset ---------- */

function resetInterface() {
    clearOutput();
    clearStatus();
    setBusy(false);
}

/* ---------- Startup ---------- */

resetInterface();
requireBrowserSupport();
