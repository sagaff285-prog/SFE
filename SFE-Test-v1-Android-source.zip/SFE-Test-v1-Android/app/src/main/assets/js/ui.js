/* ==========================================
   Simple File Encryptor 3.0
   User interface controls
========================================== */

"use strict";

/* ---------- Mode tabs ---------- */

DOM.encryptTab.addEventListener("click", () => setMode("encrypt"));
DOM.decryptTab.addEventListener("click", () => setMode("decrypt"));

/* ---------- Picker mode ---------- */

DOM.pickerSingle?.addEventListener("click", () => {
    if (State.busy) return;
    setPickerMode("single");
    DOM.fileInput.value = "";
});

DOM.pickerFiles?.addEventListener("click", () => {
    if (State.busy) return;
    setPickerMode("multiple");
    DOM.fileInput.value = "";
});

DOM.pickerFolder?.addEventListener("click", () => {
    if (State.busy) return;
    setPickerMode("folder");
    DOM.fileInput.value = "";
});

/* ---------- Argon2id memory ----------
   The range and number inputs preview a valid value as the person types, but
   the input text is only rewritten on change (blur or Enter). Rewriting it on
   every keystroke would fight the typing. */

function previewArgon2Memory(rawValue) {
    const value = Number.parseInt(rawValue, 10);
    if (!Number.isInteger(value) || value < ARGON2_MIN_MIB || value > ARGON2_MAX_MIB) return;

    State.argonMemoryKib = value * 1024;
    if (DOM.argonMemoryRange) DOM.argonMemoryRange.value = String(value);
    if (DOM.argonMemoryValue) DOM.argonMemoryValue.textContent = `${value} MiB`;
}

function commitArgon2Memory(rawValue) {
    try {
        setArgon2MemoryMiB(rawValue);
    } catch (error) {
        setStatus(error.message);
    }
    updateSecurityControlsUI();
}

DOM.argonMemoryRange?.addEventListener("input", () => {
    try {
        setArgon2MemoryMiB(DOM.argonMemoryRange.value);
        updateSecurityControlsUI();
    } catch (error) {
        setStatus(error.message);
    }
});

DOM.argonMemoryInput?.addEventListener("input", () => previewArgon2Memory(DOM.argonMemoryInput.value));
DOM.argonMemoryInput?.addEventListener("change", () => commitArgon2Memory(DOM.argonMemoryInput.value));

/* ---------- PBKDF2 iterations ---------- */

function previewPbkdf2Iterations(rawValue) {
    const value = Number(rawValue);
    if (!Number.isSafeInteger(value) || value < PBKDF2_MIN_ITERATIONS || value > PBKDF2_MAX_ITERATIONS) return;

    State.pbkdf2Iterations = value;
    if (DOM.pbkdf2IterationsRange) DOM.pbkdf2IterationsRange.value = String(value);
    if (DOM.pbkdf2IterationsValue) DOM.pbkdf2IterationsValue.textContent = value.toLocaleString();
}

function commitPbkdf2Iterations(rawValue) {
    try {
        setPbkdf2Iterations(rawValue);
    } catch (error) {
        setStatus(error.message);
    }
    updateSecurityControlsUI();
}

DOM.pbkdf2IterationsRange?.addEventListener("input", () => {
    try {
        setPbkdf2Iterations(DOM.pbkdf2IterationsRange.value);
        updateSecurityControlsUI();
    } catch (error) {
        setStatus(error.message);
    }
});

DOM.pbkdf2IterationsInput?.addEventListener("input", () => previewPbkdf2Iterations(DOM.pbkdf2IterationsInput.value));
DOM.pbkdf2IterationsInput?.addEventListener("change", () => commitPbkdf2Iterations(DOM.pbkdf2IterationsInput.value));

/* ---------- Password protection (KDF) picker ---------- */

const KDF_OPTION_SELECTOR = ".kdf-picker__option";

function kdfLabel(kdf) {
    return kdf === "pbkdf2" ? "PBKDF2" : "Argon2id";
}

function renderKdfPicker() {
    const current = State.kdf === "pbkdf2" ? "pbkdf2" : "argon2id";

    if (DOM.kdfValue) {
        DOM.kdfValue.textContent = kdfLabel(current);
    }

    if (DOM.kdfTrigger) {
        DOM.kdfTrigger.setAttribute("aria-expanded", String(Boolean(DOM.kdfMenu && !DOM.kdfMenu.hidden)));
    }

    if (DOM.kdfOptions) {
        DOM.kdfOptions.forEach(option => {
            const selected = option.dataset.kdf === current;
            const unavailable = option.dataset.kdf === "argon2id" && !State.argon2Available;

            option.classList.toggle("is-selected", selected);
            option.setAttribute("aria-selected", String(selected));
            option.disabled = unavailable;
            option.title = unavailable
                ? "This browser cannot run Argon2id in the background."
                : "";
        });
    }
}

function setKdfFromPicker(value) {
    if (value === "argon2id" && !State.argon2Available) {
        setStatus("Argon2id needs Web Workers, which this browser does not provide. Use PBKDF2.");
        return;
    }

    State.kdf = value === "pbkdf2" ? "pbkdf2" : "argon2id";
    renderKdfPicker();
    updateSecurityControlsUI();
}

function closeKdfPicker() {
    if (!DOM.kdfMenu || !DOM.kdfTrigger) return;
    DOM.kdfMenu.hidden = true;
    DOM.kdfTrigger.setAttribute("aria-expanded", "false");
    DOM.kdfPicker?.classList.remove("is-open");
}

function toggleKdfPicker() {
    if (!DOM.kdfMenu || !DOM.kdfTrigger || State.busy) return;

    const willOpen = DOM.kdfMenu.hidden;
    DOM.kdfMenu.hidden = !willOpen;
    DOM.kdfTrigger.setAttribute("aria-expanded", String(willOpen));
    DOM.kdfPicker?.classList.toggle("is-open", willOpen);

    if (willOpen) {
        window.requestAnimationFrame(() => {
            const selected = Array.from(DOM.kdfOptions).find(option => option.dataset.kdf === State.kdf);
            selected?.focus({ preventScroll: true });
        });
    }
}

function enabledKdfOptions() {
    return Array.from(DOM.kdfOptions).filter(option => !option.disabled);
}

if (DOM.kdfTrigger && DOM.kdfMenu && DOM.kdfOptions) {
    DOM.kdfTrigger.addEventListener("click", toggleKdfPicker);

    DOM.kdfOptions.forEach(option => {
        option.addEventListener("click", () => {
            if (option.disabled) return;
            setKdfFromPicker(option.dataset.kdf);
            closeKdfPicker();
            DOM.kdfTrigger.focus({ preventScroll: true });
        });
    });

    DOM.kdfTrigger.addEventListener("keydown", event => {
        if (event.key === "ArrowDown" || event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            toggleKdfPicker();
        }
        if (event.key === "Escape") {
            closeKdfPicker();
        }
    });

    DOM.kdfMenu.addEventListener("keydown", event => {
        const options = enabledKdfOptions();
        if (!options.length) return;

        if (event.key === "Escape") {
            event.preventDefault();
            closeKdfPicker();
            DOM.kdfTrigger.focus({ preventScroll: true });
            return;
        }

        if (event.key === "ArrowDown" || event.key === "ArrowUp") {
            event.preventDefault();
            const active = options.indexOf(document.activeElement);
            const start = active === -1 ? 0 : active;
            const delta = event.key === "ArrowDown" ? 1 : -1;
            options[(start + delta + options.length) % options.length].focus({ preventScroll: true });
            return;
        }

        if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            const focused = document.activeElement?.closest(KDF_OPTION_SELECTOR);
            if (focused && !focused.disabled) {
                setKdfFromPicker(focused.dataset.kdf);
                closeKdfPicker();
                DOM.kdfTrigger.focus({ preventScroll: true });
            }
        }
    });

    document.addEventListener("click", event => {
        if (!DOM.kdfPicker?.contains(event.target)) {
            closeKdfPicker();
        }
    });
}

/* ---------- Mode ---------- */

function setMode(mode) {
    // Switching modes replaces the file, output and password rules. It must
    // not happen while an operation is still writing into the current state.
    if (State.busy || State.mode === mode) {
        return;
    }

    State.mode = mode;

    if (mode === "decrypt") {
        State.previousEncryptPickerMode = State.pickerMode;
        State.pickerMode = "single";
    } else {
        State.pickerMode = ["single", "multiple", "folder"].includes(State.previousEncryptPickerMode)
            ? State.previousEncryptPickerMode
            : "single";
    }

    clearFile();
    updateTabs();
    updateActionButton();
    updatePickerButton();
    updatePickerModeUI();
    syncPickerInputMode();
    updatePasswordSection();
    updateSecurityControlsUI();
    closeKdfPicker();
    resetProgress();

    setStatus(mode === "encrypt" ? "Encryption mode selected." : "Decryption mode selected.");
}

/* ---------- Tabs ---------- */

function updateTabs() {
    const encrypting = State.mode === "encrypt";

    DOM.encryptTab.classList.toggle("active", encrypting);
    DOM.decryptTab.classList.toggle("active", !encrypting);
    DOM.encryptTab.setAttribute("aria-pressed", String(encrypting));
    DOM.decryptTab.setAttribute("aria-pressed", String(!encrypting));
}

/* ---------- Action and picker labels ---------- */

function updateActionButton() {
    DOM.actionButton.textContent = State.mode === "encrypt" ? "Encrypt Files" : "Decrypt File";
}

function updatePickerButton() {
    if (State.mode !== "encrypt") {
        DOM.chooseFile.textContent = "Choose encrypted file";
    } else if (State.pickerMode === "folder") {
        DOM.chooseFile.textContent = "Choose folder";
    } else if (State.pickerMode === "multiple") {
        DOM.chooseFile.textContent = "Choose multiple files";
    } else {
        DOM.chooseFile.textContent = "Choose one file";
    }
}

/* ---------- Password section ----------
   Encrypting asks for a new password (with confirmation and a strength meter).
   Decrypting asks only for the password that already protects the file. */

function updatePasswordSection() {
    const encryptMode = State.mode === "encrypt";

    if (DOM.passwordSectionTitle) {
        DOM.passwordSectionTitle.textContent = encryptMode ? "Set a password" : "Enter password";
    }

    if (DOM.passwordGenerator) DOM.passwordGenerator.hidden = !encryptMode;
    if (DOM.strengthTracker) DOM.strengthTracker.hidden = !encryptMode;
    if (DOM.securityOptions) DOM.securityOptions.hidden = !encryptMode;

    const confirmLabel = DOM.confirmPassword?.previousElementSibling;
    if (confirmLabel) confirmLabel.hidden = !encryptMode;
    if (DOM.confirmPassword) DOM.confirmPassword.hidden = !encryptMode;

    // Hint the password manager to offer a saved value only when unlocking.
    if (DOM.password) {
        DOM.password.setAttribute("autocomplete", encryptMode ? "new-password" : "current-password");
    }
    if (DOM.confirmPassword) {
        DOM.confirmPassword.setAttribute("autocomplete", "new-password");
    }

    if (DOM.generatePassword) {
        DOM.generatePassword.disabled = !encryptMode || State.busy;
        DOM.generatePassword.setAttribute("aria-hidden", String(!encryptMode));
        DOM.generatePassword.tabIndex = encryptMode ? 0 : -1;
    }

    if (!encryptMode) {
        if (DOM.confirmPassword) {
            DOM.confirmPassword.value = "";
            DOM.confirmPassword.style.borderColor = "";
        }
        clearStrengthDisplay();
    }
}

function clearStrengthDisplay() {
    if (DOM.strength) {
        DOM.strength.textContent = "Strength: —";
        DOM.strength.style.color = "";
    }
    if (DOM.strengthScore) DOM.strengthScore.textContent = "0/100";
    if (DOM.strengthMeterBar) {
        DOM.strengthMeterBar.style.width = "0%";
        DOM.strengthMeterBar.style.background = "";
    }
    if (DOM.strengthAdvice) {
        DOM.strengthAdvice.textContent = "Use a long, unique password. This tracker estimates predictability; it does not measure exact entropy.";
    }
}

/* ---------- Reset ---------- */

function resetUI() {
    DOM.password.value = "";
    DOM.confirmPassword.value = "";
    DOM.showPassword.checked = false;
    DOM.password.type = "password";
    DOM.confirmPassword.type = "password";

    clearStrengthDisplay();
    clearFile();
    updatePickerButton();
    updatePickerModeUI();
    syncPickerInputMode();
    updateTabs();
    updateActionButton();
    updatePasswordSection();
    updateSecurityControlsUI();
    setStatus("Waiting...");
}

/* ---------- Startup ----------
   Without Web Workers Argon2id cannot run, so PBKDF2 becomes the default. */

if (!State.argon2Available) {
    State.kdf = "pbkdf2";
    const help = document.getElementById("kdfHelp");
    if (help) {
        help.textContent = "This browser cannot run Argon2id in the background, so PBKDF2 is used for new files.";
    }
}

resetUI();
renderKdfPicker();
