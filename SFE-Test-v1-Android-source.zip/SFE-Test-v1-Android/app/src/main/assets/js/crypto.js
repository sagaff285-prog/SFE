/*
 * Simple File Encryptor 3.0 - SFE3 container format and cryptography.
 *
 * New encryption uses the SFE3 container format (Argon2id or PBKDF2-HMAC-SHA-256
 * key derivation, AES-256-GCM records). SFE1 and SFE2 decryption remain
 * available so existing files can be migrated.
 *
 * SFE3 is record-oriented: data is processed in 1 MiB records so large files
 * never require one giant plaintext buffer.
 *
 * The on-disk format is unchanged from 3.0.0. Changes in this file only affect
 * error reporting, input handling, and resource hygiene.
 */

"use strict";

const encoder = new TextEncoder();
const decoder = new TextDecoder("utf-8", { fatal: true });

/* ---------- Common constants ---------- */

const KEY_LENGTH = 32;
const GCM_TAG_BITS = 128;
const GCM_TAG_BYTES = GCM_TAG_BITS / 8;
const GCM_NONCE_LENGTH = 12;
const SFE3_SALT_LENGTH = 32;
const SFE3_HEADER_LENGTH = 64;
const SFE3_CHUNK_SIZE = 1024 * 1024; // 1 MiB
const SFE3_MANIFEST_PLAIN_LENGTH = 1024 * 1024; // fixed-size to hide manifest length
const SFE3_MAX_MANIFEST_FILES = 50000;
const SFE3_MAX_PATH_LENGTH = 4096;
const SFE3_MIN_PASSWORD_CODE_POINTS = 12;
const SFE3_MAX_PASSWORD_CODE_POINTS = 128;
const SFE3_MAX_TOTAL_SIZE = (4 * 1024 * 1024 * 1024) - 1;

/* ---------- SFE3 format ---------- */

const SFE3_MAGIC = new Uint8Array([0x53, 0x46, 0x45, 0x33]); // "SFE3"
const SFE3_VERSION = 1;
const SFE3_CIPHER_AES_256_GCM = 1;
const SFE3_KDF_ARGON2ID = 1;
const SFE3_KDF_PBKDF2_SHA256 = 2;
const SFE3_FLAG_NONE = 0;
const SFE3_RECORD_MANIFEST = 1;
const SFE3_RECORD_DATA = 2;
const SFE3_DEFAULT_PBKDF2_ITERATIONS = 600000;
const SFE3_MIN_PBKDF2_ITERATIONS = 600000;
const SFE3_MAX_PBKDF2_ITERATIONS = 2000000;

/* RFC 9106 second recommended Argon2id profile for memory-constrained use. */
const ARGON2_DEFAULT_MEMORY_KIB = 64 * 1024;
const ARGON2_PASSES = 3;
const ARGON2_PARALLELISM = 4;
const ARGON2_MIN_MEMORY_KIB = 12 * 1024;
const ARGON2_MAX_MEMORY_KIB = 256 * 1024;

/* ---------- Legacy formats ---------- */

const SFE1_HEADER = "SFE1";
const SFE1_PBKDF2_ITERATIONS = 250000;
const SFE2_HEADER = new Uint8Array([0x53, 0x46, 0x45, 0x32]); // "SFE2"
const SFE2_VERSION = 1;
const SFE2_KDF_ARGON2ID = 1;
const SFE2_HEADER_LENGTH = 46;

/* ---------- Errors ---------- */

/**
 * An error whose message is safe and useful to show to the person.
 * Anything that is not an SfeError is reported with a generic message.
 */
class SfeError extends Error {
    constructor(message, code = "SFE_ERROR") {
        super(message);
        this.name = "SfeError";
        this.code = code;
    }
}

const AUTH_FAILED_MESSAGE = "Wrong password, or the file has been changed or damaged.";

/* Web Crypto reports AES-GCM tag failures as OperationError. Map them once so
   callers never confuse an authentication failure with a programming error. */
function authFailure(cause) {
    const error = new SfeError(AUTH_FAILED_MESSAGE, "SFE_AUTH_FAILED");
    error.cause = cause;
    return error;
}

/* ---------- Byte helpers ---------- */

function randomBytes(length) {
    const out = new Uint8Array(length);
    crypto.getRandomValues(out);
    return out;
}

function wipe(...arrays) {
    for (const bytes of arrays) {
        if (bytes instanceof Uint8Array) bytes.fill(0);
    }
}

function writeU32LE(value) {
    const out = new Uint8Array(4);
    new DataView(out.buffer).setUint32(0, value >>> 0, true);
    return out;
}

function readU32LE(bytes, offset = 0) {
    if (offset < 0 || offset + 4 > bytes.byteLength) {
        throw new SfeError("The encrypted file is malformed.", "SFE_MALFORMED");
    }

    return new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength)
        .getUint32(offset, true);
}

function constantTimeEqual(a, b) {
    if (a.length !== b.length) return false;

    let diff = 0;
    for (let i = 0; i < a.length; i += 1) {
        diff |= a[i] ^ b[i];
    }

    return diff === 0;
}

function bytesEqualsAscii(bytes, text) {
    if (bytes.length !== text.length) return false;
    for (let i = 0; i < text.length; i += 1) {
        if (bytes[i] !== text.charCodeAt(i)) return false;
    }
    return true;
}

function concatBytes(...chunks) {
    const total = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
    const out = new Uint8Array(total);
    let offset = 0;

    for (const chunk of chunks) {
        out.set(chunk, offset);
        offset += chunk.length;
    }

    return out;
}

function addU96(base, value) {
    if (!(base instanceof Uint8Array) || base.length !== GCM_NONCE_LENGTH) {
        throw new SfeError("Invalid SFE3 nonce base.", "SFE_MALFORMED");
    }

    if (!Number.isSafeInteger(value) || value < 0 || value > 0xFFFFFFFF) {
        throw new SfeError("Invalid SFE3 record index.", "SFE_MALFORMED");
    }

    const out = base.slice();
    const view = new DataView(out.buffer, out.byteOffset, out.byteLength);
    let carry = value >>> 0;

    for (let word = 0; word < 3; word += 1) {
        const offset = word * 4;
        const sum = view.getUint32(offset, true) + carry;
        view.setUint32(offset, sum >>> 0, true);
        carry = sum > 0xFFFFFFFF ? 1 : 0;
    }

    if (carry !== 0) {
        throw new SfeError("SFE3 nonce space exhausted.", "SFE_MALFORMED");
    }

    return out;
}

function normalizePassword(password) {
    if (typeof password !== "string") {
        throw new SfeError("Password must be text.", "SFE_INVALID_INPUT");
    }

    return typeof password.normalize === "function"
        ? password.normalize("NFC")
        : password;
}

function passwordCodePointLength(password) {
    return Array.from(normalizePassword(password)).length;
}

/* Maps 0..1 key-derivation progress into the 15..80% band of the progress bar. */
window.setKdfProgress = progress => {
    setProgress(15 + Math.min(65, progress * 65));
};

function setKdfProgressSafe(progress) {
    if (typeof window.setKdfProgress === "function") {
        window.setKdfProgress(progress);
    }
}

/* ---------- SFE3 header ---------- */

function buildSfe3Header({ kdf, cost1, cost2, cost3, salt, nonceBase }) {
    if (salt.length !== SFE3_SALT_LENGTH || nonceBase.length !== GCM_NONCE_LENGTH) {
        throw new SfeError("Invalid SFE3 salt or nonce size.", "SFE_INTERNAL");
    }

    return concatBytes(
        SFE3_MAGIC,
        new Uint8Array([SFE3_VERSION, kdf, SFE3_CIPHER_AES_256_GCM, SFE3_FLAG_NONE]),
        writeU32LE(cost1),
        writeU32LE(cost2),
        writeU32LE(cost3),
        salt,
        nonceBase
    );
}

function validateArgon2Parameters(memorySize, passes, parallelism) {
    if (
        !Number.isInteger(memorySize) ||
        !Number.isInteger(passes) ||
        !Number.isInteger(parallelism) ||
        memorySize < ARGON2_MIN_MEMORY_KIB ||
        memorySize > ARGON2_MAX_MEMORY_KIB ||
        memorySize < (8 * parallelism) ||
        passes < 1 ||
        passes > 32 ||
        parallelism < 1 ||
        parallelism > 16
    ) {
        throw new SfeError("Invalid Argon2id parameters.", "SFE_INVALID_INPUT");
    }
}

function validatePbkdf2Iterations(iterations) {
    if (
        !Number.isInteger(iterations) ||
        iterations < SFE3_MIN_PBKDF2_ITERATIONS ||
        iterations > SFE3_MAX_PBKDF2_ITERATIONS
    ) {
        throw new SfeError(
            `PBKDF2 iterations must be a whole number from ${SFE3_MIN_PBKDF2_ITERATIONS.toLocaleString()} to ${SFE3_MAX_PBKDF2_ITERATIONS.toLocaleString()}.`,
            "SFE_INVALID_INPUT"
        );
    }
}

function parseSfe3Header(bytes) {
    if (bytes.length !== SFE3_HEADER_LENGTH) {
        throw new SfeError("This SFE3 file is truncated.", "SFE_TRUNCATED");
    }

    if (!constantTimeEqual(bytes.slice(0, 4), SFE3_MAGIC)) {
        throw new SfeError("This is not an SFE3 file.", "SFE_NOT_SFE");
    }

    const version = bytes[4];
    const kdf = bytes[5];
    const cipher = bytes[6];
    const flags = bytes[7];
    const cost1 = readU32LE(bytes, 8);
    const cost2 = readU32LE(bytes, 12);
    const cost3 = readU32LE(bytes, 16);
    const salt = bytes.slice(20, 52);
    const nonceBase = bytes.slice(52, 64);

    if (version !== SFE3_VERSION) {
        throw new SfeError("This SFE3 file uses an unsupported version.", "SFE_UNSUPPORTED");
    }

    if (cipher !== SFE3_CIPHER_AES_256_GCM || flags !== SFE3_FLAG_NONE) {
        throw new SfeError("This SFE3 file uses an unsupported cipher or option.", "SFE_UNSUPPORTED");
    }

    if (kdf === SFE3_KDF_ARGON2ID) {
        // SFE3 v1 writes 3 passes / 4 lanes. Do not let an unauthenticated
        // header request arbitrary CPU-heavy work before the key is verified.
        if (cost2 !== ARGON2_PASSES || cost3 !== ARGON2_PARALLELISM || cost1 % 1024 !== 0) {
            throw new SfeError("This SFE3 file uses an unsupported Argon2id profile.", "SFE_UNSUPPORTED");
        }
        if (cost1 < ARGON2_MIN_MEMORY_KIB || cost1 > ARGON2_MAX_MEMORY_KIB) {
            throw new SfeError("This SFE3 file uses an unsupported Argon2id memory setting.", "SFE_UNSUPPORTED");
        }
    } else if (kdf === SFE3_KDF_PBKDF2_SHA256) {
        if (cost2 !== 0 || cost3 !== 0) {
            throw new SfeError("This SFE3 file has invalid PBKDF2 parameters.", "SFE_UNSUPPORTED");
        }
        if (cost1 < SFE3_MIN_PBKDF2_ITERATIONS || cost1 > SFE3_MAX_PBKDF2_ITERATIONS) {
            throw new SfeError("This SFE3 file uses an unsupported PBKDF2 iteration count.", "SFE_UNSUPPORTED");
        }
    } else {
        throw new SfeError("This SFE3 file uses an unsupported key derivation function.", "SFE_UNSUPPORTED");
    }

    return {
        header: bytes.slice(),
        version,
        kdf,
        cipher,
        flags,
        cost1,
        cost2,
        cost3,
        salt,
        nonceBase
    };
}

function formatArgon2Memory(kib) {
    return `${Math.round(kib / 1024)} MiB`;
}

function describeSfe3Kdf(header) {
    if (header.kdf === SFE3_KDF_ARGON2ID) {
        return `Argon2id (${formatArgon2Memory(header.cost1)}, ${header.cost2} passes, ${header.cost3} lanes)`;
    }

    return `PBKDF2-HMAC-SHA-256 (${header.cost1.toLocaleString()} iterations)`;
}

/* ---------- SFE3 key derivation ---------- */

async function deriveSfe3Key(password, header) {
    const passwordBytes = encoder.encode(normalizePassword(password));
    let keyMaterial = null;

    try {
        if (header.kdf === SFE3_KDF_ARGON2ID) {
            keyMaterial = await window.SFEArgon2idClient.derive(
                passwordBytes,
                header.salt,
                { m: header.cost1, t: header.cost2, p: header.cost3 },
                progress => setKdfProgressSafe(progress)
            );
        } else {
            const passwordKey = await crypto.subtle.importKey(
                "raw",
                passwordBytes,
                "PBKDF2",
                false,
                ["deriveBits"]
            );

            const bits = await crypto.subtle.deriveBits(
                {
                    name: "PBKDF2",
                    hash: "SHA-256",
                    salt: header.salt,
                    iterations: header.cost1
                },
                passwordKey,
                KEY_LENGTH * 8
            );

            keyMaterial = new Uint8Array(bits);
            setKdfProgressSafe(1);
        }
    } finally {
        wipe(passwordBytes);
    }

    if (!(keyMaterial instanceof Uint8Array) || keyMaterial.length !== KEY_LENGTH) {
        wipe(keyMaterial);
        throw new SfeError("Key derivation returned invalid key material.", "SFE_INTERNAL");
    }

    try {
        return await crypto.subtle.importKey(
            "raw",
            keyMaterial,
            { name: "AES-GCM" },
            false,
            ["encrypt", "decrypt"]
        );
    } finally {
        wipe(keyMaterial);
    }
}

/* ---------- SFE3 record cryptography ---------- */

function getSfe3RecordNonce(header, recordIndex) {
    return addU96(header.nonceBase, recordIndex);
}

function buildSfe3RecordAAD(header, recordType, recordIndex) {
    return concatBytes(
        header.header,
        new Uint8Array([recordType]),
        writeU32LE(recordIndex)
    );
}

async function encryptSfe3Record(key, header, recordType, recordIndex, plaintext) {
    const nonce = getSfe3RecordNonce(header, recordIndex);
    const aad = buildSfe3RecordAAD(header, recordType, recordIndex);

    const ciphertext = await crypto.subtle.encrypt(
        {
            name: "AES-GCM",
            iv: nonce,
            additionalData: aad,
            tagLength: GCM_TAG_BITS
        },
        key,
        plaintext
    );

    return concatBytes(
        new Uint8Array([recordType]),
        nonce,
        new Uint8Array(ciphertext)
    );
}

async function decryptSfe3Record(key, header, recordType, recordIndex, recordBytes, expectedCipherLength) {
    const expectedLength = 1 + GCM_NONCE_LENGTH + expectedCipherLength;

    if (recordBytes.length !== expectedLength) {
        throw new SfeError("This SFE3 file is truncated or damaged.", "SFE_TRUNCATED");
    }

    if (recordBytes[0] !== recordType) {
        throw new SfeError("This SFE3 file is malformed.", "SFE_MALFORMED");
    }

    const nonce = recordBytes.slice(1, 1 + GCM_NONCE_LENGTH);
    const expectedNonce = getSfe3RecordNonce(header, recordIndex);

    if (!constantTimeEqual(nonce, expectedNonce)) {
        throw new SfeError("This SFE3 file is malformed or has been reordered.", "SFE_MALFORMED");
    }

    const ciphertext = recordBytes.slice(1 + GCM_NONCE_LENGTH);
    const aad = buildSfe3RecordAAD(header, recordType, recordIndex);

    try {
        return new Uint8Array(await crypto.subtle.decrypt(
            {
                name: "AES-GCM",
                iv: nonce,
                additionalData: aad,
                tagLength: GCM_TAG_BITS
            },
            key,
            ciphertext
        ));
    } catch (cause) {
        throw authFailure(cause);
    }
}

function getSfe3RecordSize(type) {
    if (type === SFE3_RECORD_MANIFEST) {
        return 1 + GCM_NONCE_LENGTH + SFE3_MANIFEST_PLAIN_LENGTH + GCM_TAG_BYTES;
    }

    if (type === SFE3_RECORD_DATA) {
        return 1 + GCM_NONCE_LENGTH + 4 + SFE3_CHUNK_SIZE + GCM_TAG_BYTES;
    }

    throw new SfeError("Unknown SFE3 record type.", "SFE_INTERNAL");
}

/**
 * Exact on-disk size of an SFE3 container holding `plaintextBytes` of file data.
 * Used to validate the size of a container before it is selected for decryption.
 */
function sfe3ContainerSize(plaintextBytes) {
    const dataRecords = Math.ceil(plaintextBytes / SFE3_CHUNK_SIZE);
    return SFE3_HEADER_LENGTH
        + getSfe3RecordSize(SFE3_RECORD_MANIFEST)
        + dataRecords * getSfe3RecordSize(SFE3_RECORD_DATA);
}

/* ---------- SFE3 manifest ---------- */

function validateRelativePathForManifest(path) {
    if (typeof path !== "string" || path.length === 0 || path.length > SFE3_MAX_PATH_LENGTH) {
        throw new SfeError("A selected filename or path is invalid or too long.", "SFE_INVALID_INPUT");
    }

    if (path.includes("\0")) {
        throw new SfeError("A selected filename contains an invalid character.", "SFE_INVALID_INPUT");
    }

    const normalized = path.replace(/\\/g, "/");

    if (normalized.startsWith("/") || /^[A-Za-z]:\//.test(normalized)) {
        throw new SfeError("Absolute paths cannot be stored in an SFE3 container.", "SFE_INVALID_INPUT");
    }

    const parts = normalized.split("/");
    if (parts.some(part => part === "..")) {
        throw new SfeError("Parent-directory paths cannot be stored in an SFE3 container.", "SFE_INVALID_INPUT");
    }

    return parts.filter(part => part !== "" && part !== ".").join("/");
}

function buildSfe3Manifest(files) {
    if (!Array.isArray(files) || files.length === 0) {
        throw new SfeError("No files were selected.", "SFE_INVALID_INPUT");
    }

    if (files.length > SFE3_MAX_MANIFEST_FILES) {
        throw new SfeError(
            `Too many files selected. The maximum is ${SFE3_MAX_MANIFEST_FILES.toLocaleString()}.`,
            "SFE_INVALID_INPUT"
        );
    }

    const entries = [];
    const seen = new Set();
    let totalSize = 0;

    for (const file of files) {
        if (!(file instanceof Blob)) {
            throw new SfeError("Invalid file selection.", "SFE_INVALID_INPUT");
        }

        const path = validateRelativePathForManifest(getRelativePath(file));

        if (seen.has(path)) {
            throw new SfeError(
                `Two selected items share the same path: ${path}. Rename one of them or encrypt them separately.`,
                "SFE_INVALID_INPUT"
            );
        }

        if (!Number.isSafeInteger(file.size) || file.size < 0 || file.size > MAX_FILE_SIZE) {
            throw new SfeError(`"${path}" is invalid or exceeds the 1 GB file limit.`, "SFE_INVALID_INPUT");
        }

        seen.add(path);
        entries.push({ path, size: file.size });
        totalSize += file.size;

        if (totalSize > SFE3_MAX_TOTAL_SIZE) {
            throw new SfeError("The selected files exceed the total size limit for one encrypted container.", "SFE_INVALID_INPUT");
        }
    }

    const manifestObject = {
        format: "SFE3",
        manifestVersion: 1,
        chunkSize: SFE3_CHUNK_SIZE,
        files: entries
    };

    const jsonBytes = encoder.encode(JSON.stringify(manifestObject));

    try {
        if (jsonBytes.length > SFE3_MANIFEST_PLAIN_LENGTH - 4) {
            throw new SfeError(
                "The file names and folder paths are too long to fit in one encrypted container. Encrypt fewer files at a time.",
                "SFE_INVALID_INPUT"
            );
        }

        const block = new Uint8Array(SFE3_MANIFEST_PLAIN_LENGTH);
        block.set(writeU32LE(jsonBytes.length), 0);
        block.set(jsonBytes, 4);

        return { block, entries, totalSize };
    } finally {
        wipe(jsonBytes);
    }
}

function parseSfe3Manifest(block) {
    if (block.length !== SFE3_MANIFEST_PLAIN_LENGTH) {
        throw new SfeError("This SFE3 manifest is malformed.", "SFE_MALFORMED");
    }

    const jsonLength = readU32LE(block, 0);

    if (jsonLength === 0 || jsonLength > SFE3_MANIFEST_PLAIN_LENGTH - 4) {
        throw new SfeError("This SFE3 manifest is malformed.", "SFE_MALFORMED");
    }

    const jsonBytes = block.slice(4, 4 + jsonLength);
    let manifest;

    try {
        manifest = JSON.parse(decoder.decode(jsonBytes));
    } catch {
        throw new SfeError("This SFE3 manifest is malformed.", "SFE_MALFORMED");
    } finally {
        wipe(jsonBytes);
    }

    if (
        !manifest ||
        manifest.format !== "SFE3" ||
        manifest.manifestVersion !== 1 ||
        manifest.chunkSize !== SFE3_CHUNK_SIZE ||
        !Array.isArray(manifest.files) ||
        manifest.files.length === 0 ||
        manifest.files.length > SFE3_MAX_MANIFEST_FILES
    ) {
        throw new SfeError("This SFE3 manifest is unsupported or malformed.", "SFE_UNSUPPORTED");
    }

    const entries = [];
    const seen = new Set();
    let totalSize = 0;

    for (const entry of manifest.files) {
        if (!entry || typeof entry.path !== "string" || !Number.isSafeInteger(entry.size)) {
            throw new SfeError("This SFE3 manifest is malformed.", "SFE_MALFORMED");
        }

        const path = validateRelativePathForManifest(entry.path);

        if (seen.has(path)) {
            throw new SfeError("This SFE3 manifest lists the same path twice.", "SFE_MALFORMED");
        }

        if (entry.size < 0 || entry.size > MAX_FILE_SIZE) {
            throw new SfeError("A file in this SFE3 manifest has an invalid size.", "SFE_MALFORMED");
        }

        totalSize += entry.size;
        if (totalSize > SFE3_MAX_TOTAL_SIZE) {
            throw new SfeError("This SFE3 manifest exceeds the supported total size.", "SFE_UNSUPPORTED");
        }

        seen.add(path);
        entries.push({ path, size: entry.size });
    }

    return { entries, totalSize };
}

/* ---------- SFE3 encryption ---------- */

function getSfe3EncryptionConfig() {
    // State is the single source of truth; the UI commits its inputs into it
    // before an operation starts (see commitSecurityInputs in ui.js).
    if (State.kdf === "pbkdf2") {
        const iterations = getPbkdf2Iterations();
        validatePbkdf2Iterations(iterations);

        return {
            kdf: SFE3_KDF_PBKDF2_SHA256,
            cost1: iterations,
            cost2: 0,
            cost3: 0
        };
    }

    const memoryKib = State.argonMemoryKib;
    validateArgon2Parameters(memoryKib, ARGON2_PASSES, ARGON2_PARALLELISM);

    return {
        kdf: SFE3_KDF_ARGON2ID,
        cost1: memoryKib,
        cost2: ARGON2_PASSES,
        cost3: ARGON2_PARALLELISM
    };
}

async function encryptSfe3Files(files, password) {
    const normalizedPassword = normalizePassword(password);
    const passwordLength = passwordCodePointLength(normalizedPassword);

    if (passwordLength < SFE3_MIN_PASSWORD_CODE_POINTS || passwordLength > SFE3_MAX_PASSWORD_CODE_POINTS) {
        throw new SfeError(
            `New encryption passwords must contain ${SFE3_MIN_PASSWORD_CODE_POINTS} to ${SFE3_MAX_PASSWORD_CODE_POINTS} characters.`,
            "SFE_INVALID_INPUT"
        );
    }

    if (isObviousWeakPassword(normalizedPassword)) {
        throw new SfeError(
            "That password is too predictable. Use a longer, less predictable password or the generator.",
            "SFE_INVALID_INPUT"
        );
    }

    const manifest = buildSfe3Manifest(files);
    let salt = null;
    let nonceBase = null;
    let headerBytes = null;
    let plainBlock = null;

    try {
        const config = getSfe3EncryptionConfig();
        salt = randomBytes(SFE3_SALT_LENGTH);
        nonceBase = randomBytes(GCM_NONCE_LENGTH);
        headerBytes = buildSfe3Header({ ...config, salt, nonceBase });
        const header = parseSfe3Header(headerBytes);
        const key = await deriveSfe3Key(normalizedPassword, header);

        // Keep the output as Blob segments. Concatenating every ciphertext
        // array into one buffer would roughly double peak memory on large jobs.
        const parts = [new Blob([headerBytes])];
        let recordIndex = 0;

        const encryptedManifest = await encryptSfe3Record(
            key,
            header,
            SFE3_RECORD_MANIFEST,
            recordIndex,
            manifest.block
        );
        parts.push(new Blob([encryptedManifest]));
        wipe(encryptedManifest);
        recordIndex += 1;

        // Records are packed across file boundaries: the payload stream is the
        // concatenation of all files in manifest order, cut into 1 MiB records.
        // Only the final record is partially filled. This matches the layout the
        // decryptor expects (ceil(total / 1 MiB) data records) and avoids a
        // padded record at every file boundary.
        plainBlock = new Uint8Array(4 + SFE3_CHUNK_SIZE);
        let recordFill = 0;
        let processed = 0;

        const flushRecord = async () => {
            if (recordFill === 0) return;

            plainBlock.set(writeU32LE(recordFill), 0);
            const encryptedRecord = await encryptSfe3Record(
                key,
                header,
                SFE3_RECORD_DATA,
                recordIndex,
                plainBlock
            );
            parts.push(new Blob([encryptedRecord]));
            wipe(encryptedRecord);

            recordIndex += 1;
            recordFill = 0;
            plainBlock.fill(0);
            setProgress(20 + ((processed / manifest.totalSize) * 75));
        };

        for (const file of files) {
            let offset = 0;

            while (offset < file.size) {
                const want = Math.min(SFE3_CHUNK_SIZE - recordFill, file.size - offset);
                const end = offset + want;
                let chunk = null;

                try {
                    chunk = new Uint8Array(await file.slice(offset, end).arrayBuffer());

                    // A file can change on disk after it was selected. Refuse rather
                    // than write a container whose manifest disagrees with its data.
                    if (chunk.length !== want) {
                        throw new SfeError(
                            `"${getRelativePath(file)}" changed while it was being encrypted. Select it again and retry.`,
                            "SFE_SOURCE_CHANGED"
                        );
                    }

                    plainBlock.set(chunk, 4 + recordFill);
                    recordFill += want;
                    processed += want;
                    offset = end;
                } finally {
                    wipe(chunk);
                }

                if (recordFill === SFE3_CHUNK_SIZE) {
                    await flushRecord();
                }
            }
        }

        await flushRecord();

        return new Blob(parts, { type: "application/octet-stream" });
    } finally {
        wipe(manifest.block, plainBlock, salt, nonceBase, headerBytes);
    }
}

/* ---------- SFE3 decryption ---------- */

async function readBlobBytes(blob, start, end) {
    return new Uint8Array(await blob.slice(start, end).arrayBuffer());
}

function getBaseFilename(path) {
    const normalized = path.replace(/\\/g, "/");
    const index = normalized.lastIndexOf("/");
    return index === -1 ? normalized : normalized.slice(index + 1);
}

async function decryptSfe3File(file, password) {
    // Reject obviously truncated containers before performing an expensive KDF.
    const manifestRecordSize = getSfe3RecordSize(SFE3_RECORD_MANIFEST);
    if (file.size < SFE3_HEADER_LENGTH + manifestRecordSize) {
        throw new SfeError("This SFE3 file is truncated.", "SFE_TRUNCATED");
    }

    let headerBytes = null;

    try {
        headerBytes = await readBlobBytes(file, 0, SFE3_HEADER_LENGTH);
        const header = parseSfe3Header(headerBytes);
        const key = await deriveSfe3Key(password, header);
        const dataRecordSize = getSfe3RecordSize(SFE3_RECORD_DATA);

        setProgress(15);

        const manifestBytes = await readBlobBytes(
            file,
            SFE3_HEADER_LENGTH,
            SFE3_HEADER_LENGTH + manifestRecordSize
        );

        let manifestPlain = null;
        let manifest;
        try {
            manifestPlain = await decryptSfe3Record(
                key,
                header,
                SFE3_RECORD_MANIFEST,
                0,
                manifestBytes,
                SFE3_MANIFEST_PLAIN_LENGTH + GCM_TAG_BYTES
            );
            manifest = parseSfe3Manifest(manifestPlain);
        } finally {
            wipe(manifestBytes, manifestPlain);
        }

        const expectedDataRecords = Math.ceil(manifest.totalSize / SFE3_CHUNK_SIZE);
        const dataStart = SFE3_HEADER_LENGTH + manifestRecordSize;
        const remaining = file.size - dataStart;

        if (remaining !== expectedDataRecords * dataRecordSize) {
            throw new SfeError("This SFE3 file is truncated or has extra data.", "SFE_TRUNCATED");
        }

        const states = manifest.entries.map(entry => ({
            path: entry.path,
            size: entry.size,
            parts: [],
            written: 0,
            crc: 0xFFFFFFFF
        }));

        let currentFile = 0;
        let currentOffset = 0;
        let processed = 0;

        // Zero-byte files occupy a manifest entry but no data bytes.
        const skipFinishedEntries = () => {
            while (currentFile < states.length && currentOffset === states[currentFile].size) {
                currentFile += 1;
                currentOffset = 0;
            }
        };
        skipFinishedEntries();

        for (let record = 0; record < expectedDataRecords; record += 1) {
            const start = dataStart + (record * dataRecordSize);
            const end = start + dataRecordSize;
            let recordBytes = await readBlobBytes(file, start, end);
            let plain = null;

            try {
                plain = await decryptSfe3Record(
                    key,
                    header,
                    SFE3_RECORD_DATA,
                    record + 1,
                    recordBytes,
                    4 + SFE3_CHUNK_SIZE + GCM_TAG_BYTES
                );

                const actualLength = readU32LE(plain, 0);
                const remainingPlain = manifest.totalSize - processed;
                const expectedLength = Math.min(SFE3_CHUNK_SIZE, remainingPlain);

                if (actualLength !== expectedLength) {
                    throw new SfeError("This SFE3 file has an invalid data record.", "SFE_MALFORMED");
                }

                let chunkOffset = 0;
                while (chunkOffset < actualLength) {
                    skipFinishedEntries();
                    if (currentFile >= states.length) {
                        throw new SfeError("This SFE3 file has more data than its manifest lists.", "SFE_MALFORMED");
                    }

                    const state = states[currentFile];
                    const remainingFileBytes = state.size - currentOffset;
                    const take = Math.min(remainingFileBytes, actualLength - chunkOffset);
                    const part = plain.subarray(4 + chunkOffset, 4 + chunkOffset + take);

                    // Blob copies its input synchronously, so the plaintext record
                    // can be wiped right after the loop without keeping a second copy.
                    state.crc = crc32Update(state.crc, part);
                    state.parts.push(new Blob([part]));
                    state.written += take;

                    chunkOffset += take;
                    currentOffset += take;

                    if (currentOffset === state.size) {
                        currentFile += 1;
                        currentOffset = 0;
                        skipFinishedEntries();
                    }
                }

                processed += actualLength;
                setProgress(20 + ((processed / manifest.totalSize) * 70));
            } finally {
                wipe(recordBytes, plain);
                recordBytes = null;
            }
        }

        skipFinishedEntries();
        if (currentFile !== states.length || currentOffset !== 0 || processed !== manifest.totalSize) {
            throw new SfeError("This SFE3 file's data does not match its manifest.", "SFE_MALFORMED");
        }

        const outputs = states.map(state => ({
            name: sanitizeArchivePath(state.path),
            blob: new Blob(state.parts, { type: "application/octet-stream" }),
            size: state.size,
            crc32: crc32Finalize(state.crc)
        }));

        if (outputs.length === 1) {
            setOutput(outputs[0].blob, getBaseFilename(outputs[0].name));
        } else {
            const zipBlob = await createZipBlobFromBlobEntries(outputs);
            setOutput(zipBlob, "decrypted_files.zip");
        }

        completeProgress();
        return {
            fileCount: outputs.length,
            kdfDescription: describeSfe3Kdf(header)
        };
    } finally {
        wipe(headerBytes);
    }
}

/* ---------- Legacy SFE1 / SFE2 decryption (migration only) ---------- */

async function decryptSfe1(buffer, password) {
    const bytes = new Uint8Array(buffer);

    if (bytes.length < 4 + 16 + 12 + GCM_TAG_BYTES) {
        throw new SfeError("This encrypted file is truncated.", "SFE_TRUNCATED");
    }

    if (!bytesEqualsAscii(bytes.subarray(0, 4), SFE1_HEADER)) {
        throw new SfeError("This is not an SFE1 file.", "SFE_NOT_SFE");
    }

    const salt = bytes.slice(4, 20);
    const iv = bytes.slice(20, 32);
    const data = bytes.slice(32);
    const passwordBytes = encoder.encode(password);

    try {
        const passwordKey = await crypto.subtle.importKey(
            "raw",
            passwordBytes,
            "PBKDF2",
            false,
            ["deriveKey"]
        );

        const key = await crypto.subtle.deriveKey(
            {
                name: "PBKDF2",
                hash: "SHA-256",
                salt,
                iterations: SFE1_PBKDF2_ITERATIONS
            },
            passwordKey,
            { name: "AES-GCM", length: 256 },
            false,
            ["decrypt"]
        );

        return await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, data);
    } catch (cause) {
        if (cause instanceof SfeError) throw cause;
        throw authFailure(cause);
    } finally {
        wipe(passwordBytes, salt, iv, data);
    }
}

async function deriveLegacyArgon2id(password, salt, memorySize, passes, parallelism) {
    const passwordBytes = encoder.encode(password);

    try {
        const result = await window.SFEArgon2idClient.derive(
            passwordBytes,
            salt,
            { m: memorySize, t: passes, p: parallelism },
            progress => setKdfProgressSafe(progress)
        );

        if (!(result instanceof Uint8Array) || result.length !== KEY_LENGTH) {
            wipe(result);
            throw new SfeError("Key derivation returned an invalid legacy key.", "SFE_INTERNAL");
        }

        try {
            return await crypto.subtle.importKey(
                "raw",
                result,
                { name: "AES-GCM" },
                false,
                ["decrypt"]
            );
        } finally {
            wipe(result);
        }
    } finally {
        wipe(passwordBytes);
    }
}

function parseSfe2(buffer) {
    const bytes = new Uint8Array(buffer);

    if (bytes.length < SFE2_HEADER_LENGTH + GCM_TAG_BYTES) {
        throw new SfeError("This encrypted file is truncated.", "SFE_TRUNCATED");
    }

    if (!constantTimeEqual(bytes.slice(0, 4), SFE2_HEADER)) {
        throw new SfeError("This is not an SFE2 file.", "SFE_NOT_SFE");
    }

    const version = bytes[4];
    const kdf = bytes[5];
    const memorySize = readU32LE(bytes, 6);
    const passes = readU32LE(bytes, 10);
    const parallelism = readU32LE(bytes, 14);

    if (version !== SFE2_VERSION || kdf !== SFE2_KDF_ARGON2ID) {
        throw new SfeError("This SFE2 file uses an unsupported version or key derivation function.", "SFE_UNSUPPORTED");
    }

    if (
        memorySize < ARGON2_MIN_MEMORY_KIB || memorySize > ARGON2_MAX_MEMORY_KIB ||
        passes < 1 || passes > 32 || parallelism < 1 || parallelism > 16 ||
        memorySize < 8 * parallelism
    ) {
        throw new SfeError("This legacy SFE2 file uses unsupported Argon2id settings.", "SFE_UNSUPPORTED");
    }

    return {
        header: bytes.slice(0, SFE2_HEADER_LENGTH),
        salt: bytes.slice(18, 34),
        iv: bytes.slice(34, 46),
        data: bytes.slice(SFE2_HEADER_LENGTH),
        memorySize,
        passes,
        parallelism
    };
}

async function decryptSfe2(parsed, password) {
    const key = await deriveLegacyArgon2id(
        password,
        parsed.salt,
        parsed.memorySize,
        parsed.passes,
        parsed.parallelism
    );

    try {
        return await crypto.subtle.decrypt(
            {
                name: "AES-GCM",
                iv: parsed.iv,
                additionalData: parsed.header,
                tagLength: GCM_TAG_BITS
            },
            key,
            parsed.data
        );
    } catch (cause) {
        throw authFailure(cause);
    } finally {
        wipe(parsed.salt, parsed.iv, parsed.header);
    }
}

/* ---------- Top-level operations ---------- */

/** Identify the container format from its first four bytes. */
async function detectFormat(blob) {
    if (blob.size < 4) return null;

    const magic = await readBlobBytes(blob, 0, 4);
    try {
        for (const format of ["SFE3", "SFE2", "SFE1"]) {
            if (bytesEqualsAscii(magic, format)) return format;
        }
        return null;
    } finally {
        wipe(magic);
    }
}

// Security configuration hooks were removed: the UI state in State is now the
// single source of truth, and crypto.js validates it directly.

/** Translate any error into a sentence the person can act on. */
function userMessageFor(error, fallback) {
    if (error instanceof SfeError) return error.message;

    if (typeof error?.code === "string" && error.code.startsWith("KDF_")) {
        return error.message || "Argon2id could not run. Open SFE over HTTPS and try again.";
    }

    if (error?.name === "NotReadableError") {
        return "A selected file could not be read. It may have been moved, deleted, or changed. Select it again.";
    }

    if (error instanceof RangeError || error?.name === "QuotaExceededError") {
        return "This file is too large for this browser to process in memory. Try a smaller file or a device with more memory.";
    }

    return fallback;
}

async function encryptFiles(files, password) {
    clearOutput();
    try {
        setBusy(true);
        setStatus("Preparing secure SFE3 container...");
        resetProgress();

        const output = await encryptSfe3Files(files, password);
        setOutput(output, buildEncryptedName());
        completeProgress();

        const config = getSfe3EncryptionConfig();
        setStatus(`Encrypted with ${describeSfe3Kdf(config)} + AES-256-GCM. SFE3 metadata protection enabled.`);
        return true;
    } catch (error) {
        console.error(error);
        clearOutput();
        setStatus(userMessageFor(error, "Encryption failed. Try again, or use fewer or smaller files."));
        return false;
    } finally {
        setBusy(false);
    }
}

async function decryptFile(file, password) {
    clearOutput();
    try {
        setBusy(true);
        setStatus("Inspecting encrypted container...");
        resetProgress();

        const format = await detectFormat(file);

        if (format === "SFE3") {
            setStatus("Deriving SFE3 decryption key...");
            const result = await decryptSfe3File(file, password);
            setStatus(`SFE3 decrypted successfully using ${result.kdfDescription}.`);
            return true;
        }

        if (format === "SFE1") {
            setStatus("Decrypting legacy SFE1 container...");
            const decrypted = await decryptSfe1(await file.arrayBuffer(), password);
            setOutput(new Blob([decrypted], { type: "application/octet-stream" }), buildDecryptedName(file.name));
            completeProgress();
            setStatus("Legacy SFE1 file decrypted successfully.");
            return true;
        }

        if (format === "SFE2") {
            const parsed = parseSfe2(await file.arrayBuffer());
            setStatus(`Decrypting legacy SFE2 container (${formatArgon2Memory(parsed.memorySize)}, ${parsed.passes} passes)...`);
            const decrypted = await decryptSfe2(parsed, password);
            setOutput(new Blob([decrypted], { type: "application/octet-stream" }), buildDecryptedName(file.name));
            completeProgress();
            setStatus("Legacy SFE2 file decrypted successfully.");
            return true;
        }

        throw new SfeError(
            "This is not an SFE encrypted file. Choose a .sfe3 file created by Simple File Encryptor.",
            "SFE_NOT_SFE"
        );
    } catch (error) {
        console.error(error);
        clearOutput();
        setStatus(userMessageFor(error, "Decryption failed. Check the file and password, then try again."));
        return false;
    } finally {
        setBusy(false);
    }
}

async function processFiles(files, password) {
    return State.mode === "encrypt"
        ? encryptFiles(files, password)
        : decryptFile(files[0], password);
}

/* Read-only description of the SFE3 format limits. Used by the UI for validation. */
window.SFE3 = Object.freeze({
    version: SFE3_VERSION,
    format: "SFE3",
    cipher: "AES-256-GCM",
    kdfs: Object.freeze({
        argon2id: "Argon2id",
        pbkdf2: "PBKDF2-HMAC-SHA-256"
    }),
    saltBytes: SFE3_SALT_LENGTH,
    nonceBytes: GCM_NONCE_LENGTH,
    chunkBytes: SFE3_CHUNK_SIZE,
    maxTotalPlaintextBytes: SFE3_MAX_TOTAL_SIZE,
    maxContainerBytes: sfe3ContainerSize(SFE3_MAX_TOTAL_SIZE),
    minPasswordCodePoints: SFE3_MIN_PASSWORD_CODE_POINTS,
    maxPasswordCodePoints: SFE3_MAX_PASSWORD_CODE_POINTS,
    argon2id: Object.freeze({
        defaultMemoryKiB: ARGON2_DEFAULT_MEMORY_KIB,
        minMemoryKiB: ARGON2_MIN_MEMORY_KIB,
        maxMemoryKiB: ARGON2_MAX_MEMORY_KIB,
        passes: ARGON2_PASSES,
        parallelism: ARGON2_PARALLELISM
    }),
    pbkdf2: Object.freeze({
        defaultIterations: SFE3_DEFAULT_PBKDF2_ITERATIONS,
        minIterations: SFE3_MIN_PBKDF2_ITERATIONS,
        maxIterations: SFE3_MAX_PBKDF2_ITERATIONS
    })
});
