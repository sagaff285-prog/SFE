/*
 * Simple File Encryptor 3.0 - Argon2id worker.
 *
 * Dedicated, reusable worker for expensive Argon2id derivation so the UI stays
 * responsive. The engine is imported lazily on the first derivation request.
 */
"use strict";

// The engine targets a `window` global; alias it to the worker global.
self.window = self;

let engine = null;

function loadEngine() {
    if (engine) return engine;

    try {
        importScripts("./argon2id.js");
    } catch (cause) {
        const error = new Error("Argon2id engine failed to load inside the worker.");
        error.code = "KDF_ENGINE_LOAD_FAILED";
        error.cause = cause;
        throw error;
    }

    const loaded = self.SFEArgon2id;
    if (!loaded || typeof loaded.derive !== "function") {
        const error = new Error("Argon2id engine failed to initialize inside the worker.");
        error.code = "KDF_ENGINE_LOAD_FAILED";
        throw error;
    }

    engine = loaded;
    return engine;
}

function isValidParams(params) {
    return Boolean(params) &&
        Number.isInteger(params.m) &&
        Number.isInteger(params.t) &&
        Number.isInteger(params.p) &&
        params.m > 0 && params.t > 0 && params.p > 0;
}

self.addEventListener("message", event => {
    const message = event.data || {};
    if (message.type !== "derive") return;

    let password = null;
    let salt = null;
    let key = null;

    try {
        if (!isValidParams(message.params)) {
            const error = new Error("Invalid Argon2id parameters.");
            error.code = "KDF_INVALID_PARAMS";
            throw error;
        }

        password = new Uint8Array(message.passwordBuffer);
        salt = new Uint8Array(message.saltBuffer);

        const argon = loadEngine();
        let lastReported = 0;

        key = argon.derive(password, salt, message.params, progress => {
            const value = Math.max(0, Math.min(1, Number(progress) || 0));
            if (value >= 1 || value - lastReported >= 0.01) {
                lastReported = value;
                self.postMessage({ type: "progress", id: message.id, progress: value });
            }
        });

        if (!(key instanceof Uint8Array) || key.byteLength !== 32) {
            throw new Error("Argon2id returned invalid key material.");
        }

        // Transfer a copy so the worker-local key can be wiped in `finally`.
        const keyBuffer = key.slice().buffer;
        self.postMessage({ type: "result", id: message.id, keyBuffer }, [keyBuffer]);
    } catch (error) {
        self.postMessage({
            type: "error",
            id: message.id,
            code: (error && error.code) || "KDF_DERIVATION_FAILED",
            message: error instanceof Error ? error.message : "Argon2id key derivation failed."
        });
    } finally {
        if (password) password.fill(0);
        if (salt) salt.fill(0);
        if (key) key.fill(0);
    }
});

self.postMessage({ type: "ready" });
