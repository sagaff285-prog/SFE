#include <jni.h>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>

namespace {
long readTracerPid() {
    std::ifstream input("/proc/self/status");
    if (!input.is_open()) return -1;
    std::string line;
    while (std::getline(input, line)) {
        constexpr char prefix[] = "TracerPid:";
        if (line.rfind(prefix, 0) == 0) {
            try { return std::stol(line.substr(sizeof(prefix) - 1)); }
            catch (...) { return -1; }
        }
    }
    return -1;
}

long countWritableExecutableMappings() {
    std::ifstream input("/proc/self/maps");
    if (!input.is_open()) return -1;
    std::string line;
    long count = 0;
    while (std::getline(input, line)) {
        std::istringstream row(line);
        std::string addressRange;
        std::string permissions;
        if (!(row >> addressRange >> permissions)) continue;
        if (permissions.size() >= 3 && permissions[1] == 'w' && permissions[2] == 'x') {
            ++count;
        }
    }
    return count;
}
}  // namespace

extern "C" JNIEXPORT jstring JNICALL
Java_com_simplefileencryptor_testv1_NativeChecks_snapshotNative(JNIEnv* env, jobject /* instance */) {
    const long tracerPid = readTracerPid();
    const long writableExecutableMappings = countWritableExecutableMappings();
    std::ostringstream json;
    json << "{\"tracerPid\":" << tracerPid
         << ",\"writableExecutableMappings\":" << writableExecutableMappings << "}";
    return env->NewStringUTF(json.str().c_str());
}
