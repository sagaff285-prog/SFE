# SFE Test v1 — Android source project

This is a native Android Studio project built around the user's supplied SFE 3.0.4 release. It bundles the existing local SFE core into Android app assets, uses Android's system document picker for files and output destinations, and adds an advisory C++ process-integrity probe. It has no account system and the manifest intentionally declares no INTERNET or broad storage permission.

## What is actually in this Test v1

- Existing local encryption/decryption implementation is preserved from the supplied release: SFE3 v1 encryption, Argon2id or PBKDF2-HMAC-SHA-256 key derivation, AES-256-GCM record authentication, plus SFE1/SFE2 legacy decryption paths.
- New explicit `Choose one file`, `Choose multiple files`, and (browser-only) folder selection behavior. Android Test v1 hides folder selection because WebView's file chooser does not implement the browser-specific `webkitdirectory` contract.
- No login, account, cloud storage, analytics, or file uploads by this app.
- Native Android shell: Kotlin + Jetpack Compose hosting first-party local HTML/JS through `WebViewAssetLoader`, which serves bundled content on an HTTPS-like same-origin URL so WebCrypto/workers can follow secure-origin rules.
- Native Save As path: encrypted/decrypted output Blob is streamed in 128 KiB chunks to a user-selected Android Storage Access Framework destination. The bridge never sends it over a network.
- C++ JNI diagnostics: reads only this app process's `/proc/self/status` TracerPid and `/proc/self/maps` writable-executable mapping count. Kotlin also reports Android's debugger-attached signal and whether this is a debuggable build. These are heuristics only; a clean result is not proof of device integrity.
- Version branding is removed from visible screen titles/footers. Technical documentation keeps format identifiers so users can see what file format is being processed.

## Important implementation boundary

The SFE cryptographic core is **the existing JavaScript/WebCrypto engine included in the uploaded release**, not a new C++ reimplementation. C++ is used only for local runtime-integrity heuristics. This choice preserves file-format compatibility for Test v1 and avoids pretending that a fresh native port is interoperable before test vectors exist. No passwords or original plaintext files are passed to the diagnostic JNI code.

The Floot preview is a separate UI prototype and is not the engine used here.

## Build an APK

### Easiest route: GitHub Actions

1. Create a GitHub repository and upload/extract the contents of this ZIP at its root.
2. Push to the default branch.
3. Open **Actions** and select **Build SFE Test v1 APK**. It installs JDK 17, Android SDK API 36, NDK 27.0.12077973, and CMake 3.22.1, then runs `gradle assembleDebug`.
4. Download the workflow artifact named `sfe-test-v1-debug-apk`. It contains `app-debug.apk`.
5. Transfer the APK to the Android device and install it. Android may require allowing installation from the source app used to open it; only install APKs you built or trust.

The workflow is a build path, not a release-signing setup. The debug APK is for Test v1 only. Do not distribute it as a production release.

### Android Studio

Open the folder as an Android Studio project and sync Gradle. Use JDK 17 and install Android SDK Platform 36, Android SDK Build-Tools 36.0.0, NDK 27.0.12077973, and CMake 3.22.1. Then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The resulting debug APK is at `app/build/outputs/apk/debug/app-debug.apk`.

The environment used to create this archive had Java 21 but no Android SDK, Gradle executable, or network access to download the Android build toolchain, so **no APK binary has been compiled or device-tested in this session**. The attached artifact is the complete source project plus an automated build workflow, not a prebuilt APK.

## Test checklist before relying on it

- Encrypt one file, download `.sfe3`, then decrypt it in the Android app.
- Encrypt multiple files into one container; decrypt it and verify that the restored ZIP/file set matches the source names and bytes.
- Cross-check Android-generated output with the current SFE web release in both directions.
- Wrong password, altered header/tag, truncated container and reordered/corrupt records should fail closed.
- Test files from local storage and a document provider, save to a chosen local destination, cancel file/save pickers, and test insufficient storage.
- Verify dark/light mode, back navigation, keyboard/touch focus, and the single/multiple picker states.
- Compare native diagnostics on debug builds, non-debug builds, emulators and physical devices; document false positives instead of treating a clear screen as proof of safety.

## Security notes

- Android file access uses the Storage Access Framework; the app does not ask for all-files permission.
- WebView JavaScript is enabled because it is required by the bundled app. Navigation is restricted to the bundled `appassets.androidplatform.net/assets/` origin and Internet permission is absent. Keep the JS interface inaccessible to remote content.
- The diagnostic bridge is deliberately read-only except for theme-bar updates and the explicit user-initiated, chunked Save As path. It does not read other processes' memory.
- Wiping JavaScript and native buffers cannot guarantee all runtime copies are erased. Android process-memory signals are best-effort and can be bypassed on a compromised device.
- The core retains existing compatibility behavior; a future C++ crypto port must not replace it until byte-for-byte cross-implementation fixtures pass.
