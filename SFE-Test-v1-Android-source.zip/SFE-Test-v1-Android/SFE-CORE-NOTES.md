# SFE core provenance

This project includes the files from the `SFE-3.0.4-RELEASE.zip` supplied in this conversation without modifying the crypto implementation files. UI, selection-mode, native download and diagnostic bridge changes are separate. Cryptographic files retained from the release include `js/crypto.js`, `js/kdf.js`, `js/argon2id.js`, `js/argon2-worker.js`, and the related supporting scripts.

Test v1's only changes inside the established core's selection-mode state management are in `js/utils.js` and `js/ui.js` so the picker can explicitly select one file or multiple files. No cryptographic container, KDF, nonce, record, or authentication logic was rewritten.
